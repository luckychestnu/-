# -*- coding: utf-8 -*-
"""Codex 定时继续：选择本地 Codex 对话，在指定时间向同一对话发送预设内容。"""
from __future__ import annotations
import ctypes, datetime as dt, glob, json, os, queue, re, shutil, struct, subprocess, sys, threading, time, uuid
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from telegram_remote import TelegramRemote

APP_TITLE = "Codex 定时继续"
BASE = Path(__file__).resolve().parent
JOBS_FILE = BASE / "scheduled_jobs.json"
SETTINGS_FILE = BASE / "settings.json"
LOG_FILE = BASE / "codex_scheduled_continue.log"
CODEX_HOME = Path(os.environ.get("CODEX_HOME") or Path.home() / ".codex")
STARTUP_LNK = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / f"{APP_TITLE}.lnk"
# 桌面版对话的来源记为 vscode；子代理对话不列出
SOURCE_KINDS = ["vscode", "cli", "appServer", "exec"]
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
ACTIVE = ("待发送", "发送中", "运行中")
REPEATS = ["不重复", "每天", "每隔 N 分钟"]
TURN_STATUS = {"completed": "已完成", "interrupted": "已中断", "failed": "失败"}
SANDBOX_NAMES = {"dangerFullAccess": "完全访问", "workspaceWrite": "工作区可写", "readOnly": "只读", "externalSandbox": "外部沙箱"}
# 对话记录在这段时间内仍在写入、且最后一轮没有结束，就认为它正在桌面版里运行，推迟发送
BUSY_WINDOW, BUSY_RETRY = 600, 300
# Codex 桌面版给自带插件开的工具管道（每次启动名字不同）。桌面版开着时，它会锁住打开过的对话，
# 别的进程无法写入，所以改由桌面版自己通过这个管道发送消息
PIPE_DIR = "\\\\.\\pipe\\"
DESKTOP_PREFIX = "codex-app-tools-"
DESKTOP_POLL = 5
# 无人值守，审批类请求一律拒绝：Codex 会跳过该操作继续本轮，而不是一直卡住等待
DECLINE = {"item/commandExecution/requestApproval": {"decision": "decline"},
           "item/fileChange/requestApproval": {"decision": "decline"},
           "execCommandApproval": {"decision": "denied"}, "applyPatchApproval": {"decision": "denied"},
           "mcpServer/elicitation/request": {"action": "decline"}}

def log(msg):
    try:
        if LOG_FILE.exists() and LOG_FILE.stat().st_size > 5_000_000: LOG_FILE.replace(LOG_FILE.with_suffix(".log.1"))
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(f"[{dt.datetime.now().astimezone().strftime('%Y-%m-%d %H:%M:%S %z')}] {msg}\n")
    except OSError: pass

def stamp(epoch):
    try: return dt.datetime.fromtimestamp(float(epoch)).astimezone().strftime("%Y-%m-%d %H:%M:%S")
    except Exception: return "—"

def find_codex():
    """优先用 Codex 桌面版自带的 CLI：版本与桌面版一致，并共用桌面版的登录状态。"""
    found = []
    try:
        m = re.search(r"""CODEX_CLI_PATH\s*=\s*['"]([^'"]+)['"]""", (CODEX_HOME / "config.toml").read_text(encoding="utf-8"))
        if m: found.append(m.group(1))
    except OSError: pass
    local = os.environ.get("LOCALAPPDATA")
    if local: found += sorted(glob.glob(os.path.join(local, "OpenAI", "Codex", "bin", "*", "codex.exe")), key=os.path.getmtime, reverse=True)
    found.append(shutil.which("codex") or "")
    return next((p for p in found if p and os.path.isfile(p)), "")

def command_for(executable):
    path = executable.strip()
    resolved = path if os.path.isfile(path) else (shutil.which(path) if path else None) or find_codex()
    if not resolved: raise RuntimeError("找不到 Codex CLI。请确认已安装并登录 Codex 桌面版，或手动选择 codex.exe。")
    if os.name == "nt" and Path(resolved).suffix.lower() in (".cmd", ".bat"):
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", subprocess.list2cmdline([resolved, "app-server"])], resolved
    return [resolved, "app-server"], resolved

def thread_context(path):
    """读取对话记录最后一轮的设置，并判断最后一轮是否刚刚还在写入（可能正在桌面版里运行）。"""
    ctx, open_turn = None, False
    if not path: return None, False
    try:
        mtime = os.path.getmtime(path)
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f:
                if '"turn_context"' not in line and '"task_' not in line and '"turn_aborted"' not in line: continue
                try: o = json.loads(line)
                except ValueError: continue
                pl = o.get("payload") or {}
                if o.get("type") == "turn_context": ctx = pl
                elif o.get("type") == "event_msg" and pl.get("type") == "task_started": open_turn = True
                elif o.get("type") == "event_msg" and pl.get("type") in ("task_complete", "turn_aborted"): open_turn = False
    except OSError as e:
        log(f"读取对话记录失败：{e}"); return None, False
    return ctx, open_turn and time.time() - mtime < BUSY_WINDOW

def rollout_path(tid):
    """对话记录文件：可能在 sessions，也可能被移到了 archived_sessions。"""
    hits = glob.glob(str(CODEX_HOME / "sessions" / "**" / f"rollout-*{tid}.jsonl"), recursive=True) + \
           glob.glob(str(CODEX_HOME / "archived_sessions" / f"rollout-*{tid}.jsonl"))
    return max(hits, key=os.path.getmtime) if hits else None

def last_reply(tid, turn_id=None):
    """读取 Codex 的最终回复原文（含文件链接）；指定 turn_id 时只取那一轮。"""
    for _ in range(4):
        found = last = None
        try:
            with open(rollout_path(tid), encoding="utf-8", errors="replace") as f:
                for line in f:
                    if '"task_complete"' not in line: continue
                    try: o = json.loads(line)
                    except ValueError: continue
                    pl = o.get("payload") or {}
                    if o.get("type") != "event_msg" or pl.get("type") != "task_complete": continue
                    last = pl
                    if pl.get("turn_id") == turn_id: found = pl
        except (OSError, TypeError): pass
        pl = found if turn_id else last
        if pl is not None or not turn_id: return (pl or {}).get("last_agent_message") or ""
        time.sleep(1.5)  # 这一轮的记录可能还没写完
    return ""

def permissions(ctx):
    """把对话原有的审批/沙箱设置转换成 App Server 参数。不带上它们的话，恢复后的对话会退回默认的只读沙箱。"""
    if not ctx: return {}
    out = {}
    if ctx.get("approval_policy") in ("untrusted", "on-request", "never"): out["approvalPolicy"] = ctx["approval_policy"]
    sp = ctx.get("sandbox_policy") or {}; kind = sp.get("type"); net = bool(sp.get("network_access"))
    if kind == "danger-full-access": out["sandboxPolicy"] = {"type": "dangerFullAccess"}
    elif kind == "read-only": out["sandboxPolicy"] = {"type": "readOnly", "networkAccess": net}
    elif kind == "workspace-write":
        out["sandboxPolicy"] = {"type": "workspaceWrite", "writableRoots": sp.get("writable_roots") or [], "networkAccess": net,
                                "excludeTmpdirEnvVar": bool(sp.get("exclude_tmpdir_env_var")), "excludeSlashTmp": bool(sp.get("exclude_slash_tmp"))}
    if kind in ("danger-full-access", "read-only", "workspace-write"): out["sandbox"] = kind
    return out

def next_run(job, now):
    """下一次的时间：以这一次的原定时间为基准往后排；如果因为等 Codex 拖过了，就取之后最近的一个时间点。"""
    anchor = float(job.get("planned_at") or job["run_at"])
    if job.get("repeat") == "每天":
        t = dt.datetime.fromtimestamp(anchor) + dt.timedelta(days=1)
        while t.timestamp() <= now: t += dt.timedelta(days=1)
        return t.timestamp()
    step = max(1, int(job.get("interval_min") or 1)) * 60
    t = anchor + step
    if t <= now: t += ((now - t) // step + 1) * step
    return t

def span(minutes):
    n = int(minutes)
    if n % 1440 == 0: return f"{n // 1440} 天"
    if n % 60 == 0: return f"{n // 60} 小时"
    return f"{n // 60} 小时 {n % 60} 分钟" if n > 60 else f"{n} 分钟"

def repeat_label(job):
    rep = job.get("repeat") or "不重复"
    if rep == "不重复": return rep
    base = "每天" if rep == "每天" else f"每 {span(job.get('interval_min') or 1)}"
    seq, times = job.get("seq") or 1, job.get("times")
    return f"{base}，第 {seq}/{times} 次" if times else f"{base}，第 {seq} 次"

def keep_awake(on):
    """有任务等待时阻止系统空闲睡眠（不影响合盖或手动睡眠）。只对调用它的线程生效，所以由调度线程调用。"""
    if os.name != "nt": return
    try: ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | (0x00000001 if on else 0))
    except Exception: pass

_mutex = None
def single_instance():
    """同时开两个实例会把同一个任务发两遍，所以只允许运行一个。"""
    global _mutex
    if os.name != "nt": return True
    k = ctypes.WinDLL("kernel32", use_last_error=True); k.CreateMutexW.restype = ctypes.c_void_p
    _mutex = k.CreateMutexW(None, False, "Local\\CodexScheduledContinue")
    return ctypes.get_last_error() != 183  # ERROR_ALREADY_EXISTS

def set_autostart(on):
    if not on: STARTUP_LNK.unlink(missing_ok=True); return
    pyw = Path(sys.executable).with_name("pythonw.exe")
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:LNK_PATH);"
          "$s.TargetPath=$env:LNK_EXE;$s.Arguments=$env:LNK_ARGS;$s.WorkingDirectory=$env:LNK_DIR;$s.Save()")
    env = dict(os.environ, LNK_PATH=str(STARTUP_LNK), LNK_EXE=str(pyw if pyw.exists() else sys.executable),
               LNK_ARGS=f'"{Path(__file__).resolve()}" --minimized', LNK_DIR=str(BASE))
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], env=env, capture_output=True,
                       text=True, encoding="utf-8", errors="replace", timeout=60, creationflags=NO_WINDOW)
    if r.returncode != 0 or not STARTUP_LNK.exists(): raise RuntimeError((r.stderr or r.stdout or "创建快捷方式失败").strip()[:300])

class Busy(Exception): pass

def desktop_pipes():
    try: return [PIPE_DIR + n for n in os.listdir(PIPE_DIR) if n.startswith(DESKTOP_PREFIX)]
    except OSError: return []

def read_exact(f, n):
    buf = b""
    while len(buf) < n:
        chunk = f.read(n - len(buf))
        if not chunk: raise RuntimeError("Codex 桌面版断开了连接。")
        buf += chunk
    return buf

class DesktopTools:
    """调用 Codex 桌面版的工具（与 Codex 自己用的 codex_app 插件相同）：每帧 4 字节小端长度 + JSON-RPC。"""
    @staticmethod
    def available(): return bool(desktop_pipes())
    def _once(self, path, payload):
        with open(path, "r+b", buffering=0) as f:
            f.write(struct.pack("<I", len(payload)) + payload)
            return json.loads(read_exact(f, struct.unpack("<I", read_exact(f, 4))[0]).decode("utf-8"))
    def call(self, tool, args, caller, timeout=60):
        pipes = desktop_pipes()
        if not pipes: raise RuntimeError("Codex 桌面版没有运行。")
        payload = json.dumps({"id": 1, "jsonrpc": "2.0", "method": "tools/call", "params": {
            "arguments": args, "callerSource": "codex", "callId": f"csc-{uuid.uuid4()}", "namespace": "codex_app",
            "threadId": caller, "tool": tool, "turnId": f"csc-turn-{uuid.uuid4()}"}}, ensure_ascii=False).encode("utf-8")
        box, done = {}, threading.Event()
        def work():  # 管道读写是阻塞的，放到线程里以便超时
            for path in pipes:
                try: box["r"] = self._once(path, payload); box.pop("e", None); break
                except Exception as e: box["e"] = e
            done.set()
        threading.Thread(target=work, daemon=True).start()
        if not done.wait(timeout): raise TimeoutError(f"Codex 桌面版响应超时：{tool}")
        if "e" in box: raise RuntimeError(f"连接 Codex 桌面版失败：{box['e']}")
        r = box["r"]
        if "error" in r: raise RuntimeError(f"{tool} 失败：{r['error'].get('message')}")
        res = r.get("result") or {}
        text = "".join(i.get("text", "") for i in res.get("contentItems") or [] if i.get("type") == "inputText")
        if not res.get("success"): raise RuntimeError(f"{tool} 失败：{text[:300] or '未知原因'}")
        try: return json.loads(text)
        except ValueError: return {"text": text}

class AppServer:
    """通过 stdio 与 `codex app-server` 通信（每行一条 JSON-RPC 消息）。"""
    def __init__(self, cmd, on_event):
        self.on_event = on_event
        self.p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            encoding="utf-8", errors="replace", bufsize=1, cwd=str(Path.home()), creationflags=NO_WINDOW)
        self.seq, self.lock, self.wlock, self.pending = 1, threading.Lock(), threading.Lock(), {}
        threading.Thread(target=self._reader, daemon=True).start()
        threading.Thread(target=self._stderr, daemon=True).start()
        try:
            self.request("initialize", {"clientInfo": {"name": "codex_scheduled_continue", "title": APP_TITLE, "version": "2.0.0"}, "capabilities": {}}, 30)
            self.notify("initialized", {})
        except Exception: self.close(); raise
    def alive(self): return self.p.poll() is None
    def _write(self, data):
        with self.wlock: self.p.stdin.write(json.dumps(data, ensure_ascii=False) + "\n"); self.p.stdin.flush()
    def _emit(self, msg):
        try: self.on_event(msg)
        except Exception as e: log(f"处理 App Server 事件出错：{e}")
    def _reader(self):
        try:
            for line in self.p.stdout:
                try: msg = json.loads(line)
                except ValueError:
                    if line.strip(): log("App Server 非 JSON 输出：" + line.strip()[:300])
                    continue
                if "method" in msg and "id" in msg: self._answer(msg)  # 服务器发来的请求（审批等）
                elif "method" in msg: self._emit(msg)
                else:
                    with self.lock: waiter = self.pending.get(msg.get("id"))
                    if waiter: waiter["response"] = msg; waiter["event"].set()
        except Exception as e: log("App Server 读取异常：" + str(e))
        self._emit({"method": "_exited", "server": self})
    def _answer(self, msg):
        method = msg.get("method"); result = DECLINE.get(method)
        log(f"Codex 请求交互：{method}；无人值守，已自动{'拒绝' if result else '返回错误'}。")
        reply = {"id": msg["id"], "result": result} if result else \
                {"id": msg["id"], "error": {"code": -32000, "message": "定时发送程序无人值守，无法处理该请求。"}}
        try: self._write(reply)
        except Exception as e: log(f"回应 App Server 请求失败：{e}")
        self._emit({"method": "_declined", "params": {"request": method, "threadId": (msg.get("params") or {}).get("threadId")}})
    def _stderr(self):
        try:
            for line in self.p.stderr:
                if line.strip(): log("app-server: " + re.sub(r"\x1b\[[0-9;]*m", "", line.strip()))  # 去掉终端颜色码
        except Exception: pass
    def request(self, method, params=None, timeout=45):
        if not self.alive(): raise RuntimeError("Codex App Server 已退出，请重新连接。")
        with self.lock:
            rid = self.seq; self.seq += 1
            waiter = {"event": threading.Event(), "response": None}; self.pending[rid] = waiter
        payload = {"method": method, "id": rid}
        if params is not None: payload["params"] = params
        try: self._write(payload)
        except Exception as e:
            with self.lock: self.pending.pop(rid, None)
            raise RuntimeError(f"发送请求失败：{e}")
        if not waiter["event"].wait(timeout):
            with self.lock: self.pending.pop(rid, None)
            raise TimeoutError(f"Codex App Server 请求超时：{method}")
        with self.lock: self.pending.pop(rid, None)
        response = waiter["response"] or {}
        if "error" in response: raise RuntimeError(f"{method} 失败：{response['error'].get('message', response['error'])}")
        return response.get("result", {})
    def notify(self, method, params=None):
        data = {"method": method}
        if params is not None: data["params"] = params
        self._write(data)
    def close(self):
        try:
            if self.alive(): self.p.terminate()
        except Exception: pass

class App:
    def __init__(self, root, minimized=False):
        self.root = root; root.title(APP_TITLE); root.geometry("1060x870"); root.minsize(950, 830)
        self.uiq = queue.Queue(); self.client = None; self.client_lock = threading.Lock(); self.jobs_lock = threading.Lock()
        self.threads = {}; self.jobs = []; self.stop = threading.Event(); self.early = {}; self.turn_errors = {}; self.refreshing = 0
        self.settings_lock = threading.Lock(); self.settings = self.load_settings()
        saved = self.settings.get("codex_path") or ""
        self.exe_path = saved if os.path.isfile(saved) else (find_codex() or "codex")
        self.exe = tk.StringVar(value=self.exe_path); self.thread_var = tk.StringVar()
        self.date_var = tk.StringVar(); self.time_var = tk.StringVar()
        self.repeat_var = tk.StringVar(value="不重复"); self.interval_var = tk.StringVar(value="300"); self.times_var = tk.StringVar(value="")
        self.awake_on = bool(self.settings.get("keep_awake", True)); self.awake_var = tk.BooleanVar(value=self.awake_on)
        self.autostart_var = tk.BooleanVar(value=STARTUP_LNK.exists())
        self.status = tk.StringVar(value="正在连接 Codex…"); self.mode = tk.StringVar(value="")
        self.tg_token = tk.StringVar(value=self.settings.get("tg_token") or ""); self.tg_proxy = tk.StringVar(value=self.settings.get("tg_proxy") or "")
        self.tg_status = tk.StringVar(value=""); self.remote = TelegramRemote(self, log)
        self.build(); self.load_jobs(); self.render_jobs(self.jobs)
        threading.Thread(target=self.scheduler, daemon=True).start(); self.remote.start()
        root.after(200, self.drain); root.after(300, self.refresh); root.protocol("WM_DELETE_WINDOW", self.close)
        if minimized: root.after(100, root.iconify)
    def build(self):
        outer = ttk.Frame(self.root, padding=12); outer.pack(fill="both", expand=True)
        conn = ttk.LabelFrame(outer, text="Codex 连接（默认自动使用桌面版自带的 CLI，无需另装）", padding=8); conn.pack(fill="x", pady=(0, 8))
        ttk.Label(conn, text="CLI 路径：").grid(row=0, column=0, sticky="w")
        ttk.Entry(conn, textvariable=self.exe).grid(row=0, column=1, sticky="ew", padx=6)
        ttk.Button(conn, text="浏览…", command=self.browse).grid(row=0, column=2, padx=4)
        ttk.Button(conn, text="自动检测", command=self.autodetect).grid(row=0, column=3, padx=4)
        ttk.Button(conn, text="连接并刷新对话", command=self.refresh).grid(row=0, column=4, padx=4); conn.columnconfigure(1, weight=1)
        ttk.Label(conn, textvariable=self.mode, foreground="#1a5fb4").grid(row=1, column=0, columnspan=5, sticky="w", pady=(6, 0))
        target = ttk.LabelFrame(outer, text="选择对话与发送内容", padding=8); target.pack(fill="x", pady=(0, 8))
        ttk.Label(target, text="目标对话：").grid(row=0, column=0, sticky="w")
        self.combo = ttk.Combobox(target, textvariable=self.thread_var, state="readonly"); self.combo.grid(row=0, column=1, sticky="ew", padx=6)
        ttk.Button(target, text="刷新", command=self.refresh).grid(row=0, column=2, padx=4)
        ttk.Label(target, text="发送内容：").grid(row=1, column=0, sticky="nw", pady=(8, 0))
        self.message = tk.Text(target, height=4, wrap="word", font="TkDefaultFont", undo=True)
        self.message.grid(row=1, column=1, sticky="ew", padx=6, pady=(8, 0)); self.message.insert("1.0", self.settings.get("message") or "继续")
        ttk.Label(target, text="可多行\n默认：继续").grid(row=1, column=2, sticky="nw", pady=(8, 0)); target.columnconfigure(1, weight=1)
        sched = ttk.LabelFrame(outer, text="定时发送（电脑本地时间）", padding=8); sched.pack(fill="x", pady=(0, 8))
        soon = dt.datetime.now().astimezone() + dt.timedelta(minutes=5); self.date_var.set(soon.strftime("%Y-%m-%d")); self.time_var.set(soon.strftime("%H:%M:%S"))
        ttk.Label(sched, text="日期 YYYY-MM-DD：").grid(row=0, column=0, sticky="w")
        ttk.Entry(sched, textvariable=self.date_var, width=12).grid(row=0, column=1, sticky="w", padx=5)
        ttk.Label(sched, text="时间 HH:MM:SS：").grid(row=0, column=2, sticky="w")
        ttk.Entry(sched, textvariable=self.time_var, width=10).grid(row=0, column=3, sticky="w", padx=5)
        ttk.Label(sched, text="重复：").grid(row=0, column=4, sticky="w", padx=(8, 0))
        ttk.Combobox(sched, textvariable=self.repeat_var, values=REPEATS, state="readonly", width=11).grid(row=0, column=5, sticky="w", padx=5)
        ttk.Label(sched, text="N =").grid(row=0, column=6, sticky="w")
        ttk.Entry(sched, textvariable=self.interval_var, width=6).grid(row=0, column=7, sticky="w", padx=(3, 0))
        ttk.Label(sched, text="分钟").grid(row=0, column=8, sticky="w", padx=(3, 0))
        ttk.Label(sched, text="共").grid(row=0, column=9, sticky="w", padx=(10, 0))
        ttk.Entry(sched, textvariable=self.times_var, width=5).grid(row=0, column=10, sticky="w", padx=(3, 0))
        ttk.Label(sched, text="次（留空 = 一直重复）").grid(row=0, column=11, sticky="w", padx=(3, 0))
        btns = ttk.Frame(sched); btns.grid(row=1, column=0, columnspan=12, sticky="w", pady=(8, 0))
        ttk.Button(btns, text="添加定时任务", command=self.add_job).pack(side="left")
        ttk.Button(btns, text="立即发送测试", command=self.send_now).pack(side="left", padx=8)
        opts = ttk.Frame(outer); opts.pack(fill="x", pady=(0, 6))
        ttk.Checkbutton(opts, text="有待发送任务时阻止电脑自动睡眠", variable=self.awake_var, command=self.toggle_awake).pack(side="left")
        ttk.Checkbutton(opts, text="开机自动启动（最小化）", variable=self.autostart_var, command=self.toggle_autostart).pack(side="left", padx=16)
        tg = ttk.LabelFrame(outer, text="Telegram 远程控制（在手机上下指令、接收 Codex 的输出）", padding=8); tg.pack(fill="x", pady=(0, 8))
        ttk.Label(tg, text="机器人令牌：").grid(row=0, column=0, sticky="w")
        ttk.Entry(tg, textvariable=self.tg_token, show="•").grid(row=0, column=1, sticky="ew", padx=6)
        ttk.Label(tg, text="代理（留空 = 系统代理）：").grid(row=0, column=2, sticky="w")
        ttk.Entry(tg, textvariable=self.tg_proxy, width=24).grid(row=0, column=3, sticky="w", padx=6)
        ttk.Button(tg, text="保存并连接", command=self.tg_save).grid(row=0, column=4, padx=4)
        ttk.Button(tg, text="解除绑定", command=self.tg_unbind).grid(row=0, column=5, padx=4)
        ttk.Label(tg, textvariable=self.tg_status, foreground="#1a5fb4", wraplength=980).grid(row=1, column=0, columnspan=6, sticky="w", pady=(6, 0))
        tg.columnconfigure(1, weight=1)
        ttk.Label(outer, wraplength=1000, foreground="#555", text=(
            "程序必须保持运行（最小化即可）才能准时发送；到期时若程序未运行，下次打开后会尽快补发。"
            "Codex 桌面版开着时，由桌面版在原对话里发送，界面实时显示；桌面版没开时，程序改用后台方式发送，"
            "这时桌面版看不到进度，等这一轮跑完再打开桌面版即可。两种方式都沿用对话原来的权限与模型。")).pack(anchor="w", pady=(0, 8))
        jf = ttk.LabelFrame(outer, text="已安排的任务（双击查看详情）", padding=8); jf.pack(fill="both", expand=True)
        cols = ("when", "repeat", "thread", "message", "status", "note"); self.tree = ttk.Treeview(jf, columns=cols, show="headings", height=8)
        for col, title, width in [("when", "计划时间", 140), ("repeat", "重复", 150), ("thread", "目标对话", 200),
                                  ("message", "发送内容", 130), ("status", "状态", 110), ("note", "说明", 240)]:
            self.tree.heading(col, text=title); self.tree.column(col, width=width, stretch=(col in ("thread", "note")))
        sb = ttk.Scrollbar(jf, orient="vertical", command=self.tree.yview); self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True); sb.pack(side="right", fill="y"); self.tree.bind("<Double-1>", self.show_job)
        buttons = ttk.Frame(outer); buttons.pack(fill="x", pady=(8, 0))
        ttk.Button(buttons, text="取消 / 中断选中任务", command=self.cancel_job).pack(side="left")
        ttk.Button(buttons, text="清除已结束任务", command=self.clear_jobs).pack(side="left", padx=6)
        ttk.Label(buttons, textvariable=self.status, wraplength=720).pack(side="left", padx=12)
    def browse(self):
        p = filedialog.askopenfilename(title="选择 Codex CLI", filetypes=[("Codex CLI", "codex.exe codex.cmd *.exe *.cmd *.bat"), ("所有文件", "*.*")])
        if p: self.exe.set(p)
    def autodetect(self):
        p = find_codex()
        if p: self.exe.set(p); self.status.set("已找到 Codex CLI，点击“连接并刷新对话”。")
        else: self.status.set("没有找到 Codex CLI，请确认已安装 Codex 桌面版，或手动选择 codex.exe。")
    def toggle_awake(self):
        self.awake_on = self.awake_var.get(); self.update_settings(keep_awake=self.awake_on)
    def toggle_autostart(self):
        on = self.autostart_var.get()
        try: set_autostart(on); self.status.set("已设置开机自动启动（启动后最小化在任务栏）。" if on else "已取消开机自动启动。")
        except Exception as e: self.autostart_var.set(STARTUP_LNK.exists()); self.status.set(f"设置开机启动失败：{e}"); log(f"设置开机启动失败：{e}")
    def ui(self, kind, value): self.uiq.put((kind, value))
    def drain(self):
        try:
            while True:
                kind, val = self.uiq.get_nowait()
                if kind == "status": self.status.set(val)
                elif kind == "mode": self.mode.set(val)
                elif kind == "tg": self.tg_status.set(val)
                elif kind == "exe": self.exe.set(val)
                elif kind == "threads":
                    self.threads = val; labels = list(val); self.combo["values"] = labels
                    if labels and self.thread_var.get() not in labels: self.thread_var.set(labels[0])
                    elif not labels: self.thread_var.set("")
                elif kind == "jobs": self.render_jobs(val)
        except queue.Empty: pass
        self.root.after(200, self.drain)
    def ensure_client(self):
        with self.client_lock:
            if self.client and self.client.alive(): return self.client
            cmd, resolved = command_for(self.exe_path)
            self.client = AppServer(cmd, self.on_event); log(f"已连接 Codex App Server：{resolved}")
            if resolved != self.exe_path: self.exe_path = resolved; self.ui("exe", resolved)
            # 只记住手动指定的路径；自动检测的路径不保存，这样桌面版升级后仍能找到新版 CLI
            manual = "" if resolved == find_codex() else resolved
            if self.settings.get("codex_path", "") != manual: self.update_settings(codex_path=manual)
            return self.client
    def release_client_if_idle(self):
        """本轮结束后关闭 App Server，下次发送时重新从磁盘读取对话，避免用到过期的对话历史。"""
        with self.jobs_lock: busy = self.refreshing or any(j.get("status") in ("发送中", "运行中") and j.get("via") != "desktop" for j in self.jobs)
        if busy: return
        with self.client_lock: c, self.client = self.client, None
        if c: c.close()
    def refresh(self):
        self.exe_path = self.exe.get().strip(); threading.Thread(target=self.refresh_worker, daemon=True).start()
    def backend_threads(self):
        """用后台 App Server 列出本地对话（只读，不受桌面版的对话锁影响）。"""
        with self.jobs_lock: self.refreshing += 1
        try:
            c = self.ensure_client(); items = []; cursor = None
            for _ in range(30):
                p = {"limit": 100, "sortKey": "updated_at", "sortDirection": "desc", "sourceKinds": SOURCE_KINDS, "archived": False}
                if cursor: p["cursor"] = cursor
                r = c.request("thread/list", p, 60); items.extend(r.get("data") or []); cursor = r.get("nextCursor")
                if not cursor: break
            return [{"id": t["id"], "title": " ".join((t.get("name") or t.get("preview") or "未命名对话").split())[:60],
                     "cwd": t.get("cwd"), "updatedAt": t.get("updatedAt")} for t in items if t.get("id")]
        finally:
            with self.jobs_lock: self.refreshing -= 1
            self.release_client_if_idle()
    def refresh_worker(self):
        try:
            self.ui("status", "正在读取本地 Codex 对话…")
            mapping = {f"{t['title']} | {Path(t['cwd'] or '').name or '—'} | {stamp(t['updatedAt'])} | {t['id']}": {"id": t["id"], "title": t["title"]}
                       for t in self.backend_threads()}
            self.ui("threads", mapping); self.ui("status", f"已连接，读取到 {len(mapping)} 个本地对话。"); self.show_mode()
        except Exception as e: self.ui("status", f"读取对话失败：{e}"); log("刷新对话失败：" + str(e))
    def show_mode(self):
        on = DesktopTools.available()
        self.ui("mode", "发送方式：通过 Codex 桌面版（已检测到桌面版在运行，发送后界面实时显示）" if on else
                "发送方式：后台发送（未检测到 Codex 桌面版；打开桌面版后会自动改为通过桌面版发送）")
        return on
    def selected(self): return self.threads.get(self.thread_var.get())
    def message_text(self): return self.message.get("1.0", "end").strip()
    def new_job(self, target, msg, when, repeat="不重复", interval=None, times=None, remember=True):
        """times：一共发几次（None = 一直重复）；seq：这是第几次；planned_at：这一次的原定时间（等 Codex 时 run_at 会往后推）。"""
        if remember: self.update_settings(message=msg)
        return {"id": str(uuid.uuid4()), "thread_id": target["id"], "thread_title": target["title"], "run_at": when, "planned_at": when,
                "message": msg, "repeat": repeat, "interval_min": interval, "times": times, "seq": 1, "status": "待发送",
                "created_at": time.time(), "last_error": "", "note": ""}
    def add_job(self):
        target = self.selected(); msg = self.message_text(); repeat = self.repeat_var.get(); interval = times = None
        if not target: self.status.set("请先连接并选择一个对话。"); return
        if not msg: self.status.set("发送内容不能为空。"); return
        try: when = dt.datetime.strptime(self.date_var.get().strip() + " " + self.time_var.get().strip(), "%Y-%m-%d %H:%M:%S").timestamp()
        except ValueError: self.status.set("日期/时间格式错误，请使用 YYYY-MM-DD 和 HH:MM:SS。"); return
        if when < time.time() - 1: self.status.set("计划时间已过去；请改成未来时间，或点击“立即发送测试”。"); return
        if repeat == "每隔 N 分钟":
            try: interval = int(self.interval_var.get().strip()); assert interval >= 1
            except (ValueError, AssertionError): self.status.set("重复间隔 N 必须是不小于 1 的整数（分钟）。"); return
        if repeat != "不重复" and self.times_var.get().strip():
            try: times = int(self.times_var.get().strip()); assert times >= 1
            except (ValueError, AssertionError): self.status.set("次数必须是不小于 1 的整数；留空表示一直重复。"); return
        job = self.new_job(target, msg, when, repeat, interval, times)
        with self.jobs_lock: self.jobs.append(job); self.save_jobs(); snap = list(self.jobs)
        self.render_jobs(snap); self.status.set(f"已安排在 {stamp(when)}（{repeat_label(job)}）发送到“{target['title']}”。")
    def send_now(self):
        target = self.selected(); msg = self.message_text()
        if not target or not msg: self.status.set("请先选择对话，并填写发送内容。"); return
        if not messagebox.askyesno(APP_TITLE, f"现在就向“{target['title']}”发送：\n\n{msg[:300]}\n\n确定吗？"): return
        job = self.new_job(target, msg, time.time())
        with self.jobs_lock: self.jobs.append(job); self.save_jobs(); snap = list(self.jobs)
        self.render_jobs(snap); self.status.set("正在发送…")
    def find(self, jid): return next((j for j in self.jobs if j["id"] == jid), None)
    def scheduler(self):
        awake, last_poll = None, 0.0
        while not self.stop.is_set():
            try:
                due = None; snap = None; now = time.time()
                with self.jobs_lock:
                    for j in sorted(self.jobs, key=lambda x: float(x.get("run_at", 0))):
                        if j.get("status") == "待发送" and float(j.get("run_at", 0)) <= now:
                            j["status"] = "发送中"; self.save_jobs(); due = j["id"]; snap = list(self.jobs); break
                    want = self.awake_on and any(j.get("status") in ACTIVE for j in self.jobs)
                if want != awake: keep_awake(want); awake = want
                if snap is not None: self.ui("jobs", snap)
                if due: self.execute(due)
                if now - last_poll >= DESKTOP_POLL: last_poll = now; self.show_mode(); self.poll_desktop()
            except Exception as e: log(f"调度出错：{e}")
            self.stop.wait(1)
        keep_awake(False)
    def next_job(self, j, now):
        n = {k: v for k, v in j.items() if k not in ("turn_id", "finished_at", "spawned_next", "busy_tries", "via", "sent_at")}
        when = next_run(j, now)
        n.update(id=str(uuid.uuid4()), run_at=when, planned_at=when, seq=int(j.get("seq") or 1) + 1, status="待发送",
                 last_error="", note="", created_at=now)
        return n
    def spawn_next(self, j):
        """重复任务：这一次处理完后安排下一次（调用方持有 jobs_lock）。"""
        if (j.get("repeat") or "不重复") == "不重复" or j.get("spawned_next"): return
        if j.get("times") is not None and int(j.get("seq") or 1) >= int(j["times"]): return
        j["spawned_next"] = True; self.jobs.append(self.next_job(j, time.time()))
    def execute(self, jid):
        with self.jobs_lock:
            job = self.find(jid)
            if not job: return
            job["status"] = "发送中"; self.save_jobs(); copy = dict(job); snap = list(self.jobs)
        self.ui("jobs", snap)
        via = "desktop" if DesktopTools.available() else "backend"
        status, err, note, turn_id, busy, sent_at = "失败", "", "", None, None, None
        try:
            if via == "desktop": note, sent_at = self.send_desktop(copy)
            else: note, turn_id = self.send_backend(copy)
            status = "运行中"
        except Busy as e: busy = str(e)
        except TimeoutError as e:  # 请求可能已经送达，为避免重复不再自动重发
            status, err = "结果未知（请检查对话）", str(e); log(f"任务发送超时 {jid}: {err}")
        except Exception as e: err = str(e); log(f"任务发送失败 {jid}: {err}")
        with self.jobs_lock:
            j = self.find(jid)
            if j and busy:  # 不设上限，一直等到 Codex 停下来再发
                tries = int(j.get("busy_tries") or 0) + 1
                j.update(status="待发送", run_at=time.time() + BUSY_RETRY, busy_tries=tries,
                         note=f"{busy}，{BUSY_RETRY // 60} 分钟后再试（第 {tries} 次）")
                log(f"任务推迟 {jid}: {busy}")
            elif j:
                j.update(status=status, last_error=err, note=note, turn_id=turn_id, via=via, sent_at=sent_at)
                self.spawn_next(j)
                if status != "运行中": j["finished_at"] = time.time()
                elif turn_id and turn_id in self.early: self.apply_finish(j, *self.early.pop(turn_id))
            self.save_jobs(); snap = list(self.jobs); final = j.get("status") if j else status; after = dict(j) if j else None
        self.ui("jobs", snap)
        self.ui("status", f"任务推迟：{busy}" if busy else f"已发送，Codex 正在执行…" if final == "运行中" else f"任务结果：{final}" + (f"；{err}" if err else ""))
        if after and busy:
            if after.get("busy_tries") == 1: self.remote.job_event(after, "waiting")  # 只在第一次推迟时提醒
        elif after:
            if status == "运行中": self.remote.job_event(after, "sent")
            if final != "运行中": self.remote.job_event(after, "done", turn_id)
        if final != "运行中": self.release_client_if_idle()
    def send_desktop(self, job):
        """让 Codex 桌面版自己往原对话发消息：不受对话锁限制，沿用对话的权限与模型，界面实时显示。"""
        tools, tid = DesktopTools(), job["thread_id"]
        th = tools.call("read_thread", {"threadId": tid, "turnLimit": 1}, tid)
        state = ((th.get("thread") or {}).get("status") or {}).get("type", "unknown")
        if state == "active": raise Busy("目标对话还在执行（Codex 还没停下来）")
        # systemError 是 Codex 因出错（例如额度用完）停下来的状态，正是需要发“继续”的时候，照常发送
        sent_at = time.time()
        try: tools.call("send_message_to_thread", {"threadId": tid, "prompt": job["message"]}, tid, 90)
        except RuntimeError as e:
            if "is archived" in str(e): raise RuntimeError("目标对话已被归档，请先在 Codex 里取消归档，或改发到其他对话。") from e
            raise
        log(f"已通过 Codex 桌面版向原对话发送消息：thread={tid}")
        return "已由 Codex 桌面版发送，Codex 正在执行（可在桌面版里实时查看）", sent_at
    def send_backend(self, job):
        """桌面版没有运行时，自己启动 App Server 恢复对话并发送。"""
        c = self.ensure_client(); tid = job["thread_id"]
        th = c.request("thread/read", {"threadId": tid}, 45).get("thread") or {}
        state = (th.get("status") or {}).get("type", "unknown")
        ctx, recent = thread_context(th.get("path"))
        if state == "active": raise Busy("目标对话正在执行上一轮")
        if recent: raise Busy("目标对话的最后一轮还没结束（可能正在 Codex 桌面版里运行）")
        perms = permissions(ctx)
        resume = {"threadId": tid, "excludeTurns": True}
        resume.update({k: perms[k] for k in ("approvalPolicy", "sandbox") if k in perms})
        try: rs = c.request("thread/resume", resume, 90)
        except RuntimeError as e:
            if "active writer" not in str(e): raise
            raise RuntimeError("该对话正被 Codex 桌面版占用，但没有连上桌面版。请重新打开 Codex 桌面版后再试。") from e
        params = {"threadId": tid, "input": [{"type": "text", "text": job["message"]}]}
        params.update({k: perms[k] for k in ("approvalPolicy", "sandboxPolicy") if k in perms})
        turn = c.request("turn/start", params, 90).get("turn") or {}
        sandbox = SANDBOX_NAMES.get((rs.get("sandbox") or {}).get("type"), "未知")
        note = f"后台发送，Codex 正在执行｜权限：{sandbox}，审批：{rs.get('approvalPolicy')}｜模型：{rs.get('model')} {rs.get('reasoningEffort') or ''}".rstrip()
        if not perms: note += "｜未读到原对话权限，已使用默认设置"
        log(f"已在后台向原对话发送消息：thread={tid}, turn={turn.get('id')}, sandbox={sandbox}, approval={rs.get('approvalPolicy')}")
        return note, turn.get("id")
    def poll_desktop(self):
        """查询由桌面版执行的任务是否已经跑完。"""
        with self.jobs_lock: running = [dict(j) for j in self.jobs if j.get("status") == "运行中" and j.get("via") == "desktop"]
        if not running: return
        if not DesktopTools.available():
            for j in running: self.finish_job(j["id"], "结果未知（请检查对话）", "Codex 桌面版已关闭，无法确认这一轮是否完成。")
            return
        tools = DesktopTools()
        for j in running:
            try: th = tools.call("read_thread", {"threadId": j["thread_id"], "turnLimit": 1}, j["thread_id"], 30)
            except Exception as e: log(f"查询任务结果失败：{e}"); continue
            turn = (th.get("turns") or [{}])[0]; state = ((th.get("thread") or {}).get("status") or {}).get("type")
            sent_at = float(j.get("sent_at") or 0)
            if float(turn.get("startedAt") or 0) >= int(sent_at) - 1:  # 只认发送之后开始的那一轮
                if turn.get("status") and turn["status"] != "inProgress":
                    e = turn.get("error"); self.finish_job(j["id"], turn["status"], (e.get("message") if isinstance(e, dict) else e) or "", turn.get("id"))
            elif state != "active" and time.time() - sent_at > 180:
                self.finish_job(j["id"], "结果未知（请检查对话）", "发送后 3 分钟内没有看到新的一轮，请到 Codex 里查看。")
    def finish_job(self, jid, status, err="", turn_id=None):
        """status 可以是一轮的原始状态（completed/failed/…），也可以直接是要显示的中文状态。"""
        with self.jobs_lock:
            j = self.find(jid)
            if not j or j.get("status") != "运行中": return
            if status in TURN_STATUS: self.apply_finish(j, status, err)
            else: j.update(status=status, last_error=err, finished_at=time.time())
            self.save_jobs(); snap = list(self.jobs); final = j["status"]; after = dict(j)
        log(f"任务结束 {jid}: {final}" + (f", error={err}" if err else ""))
        self.ui("jobs", snap); self.ui("status", f"任务结果：{final}" + (f"；{err}" if err else ""))
        self.remote.job_event(after, "done", turn_id)
    def apply_finish(self, j, status, err):
        j["status"] = TURN_STATUS.get(status, f"结束（{status}）"); j["finished_at"] = time.time()
        j["note"] = "Codex 已完成本轮" if status == "completed" else j.get("note", "")
        if err: j["last_error"] = err
    def on_event(self, msg):
        m, p = msg.get("method"), msg.get("params") or {}
        if m == "turn/completed":
            t = p.get("turn") or {}; tid = t.get("id")
            err = (t.get("error") or {}).get("message") or self.turn_errors.pop(tid, "")
            with self.jobs_lock:
                j = next((x for x in self.jobs if x.get("turn_id") == tid and x.get("status") == "运行中"), None)
                if not j: self.early[tid] = (t.get("status", "unknown"), err); return
                self.apply_finish(j, t.get("status", "unknown"), err); self.save_jobs(); snap = list(self.jobs); final = j["status"]; after = dict(j)
            log(f"本轮结束：turn={tid}, status={t.get('status')}" + (f", error={err}" if err else ""))
            self.ui("jobs", snap); self.ui("status", f"任务结果：{final}" + (f"；{err}" if err else ""))
            self.remote.job_event(after, "done", tid)
            self.release_client_if_idle()
        elif m == "error" and not p.get("willRetry"):
            self.turn_errors[p.get("turnId")] = (p.get("error") or {}).get("message", "")
        elif m == "_declined":
            with self.jobs_lock:
                for j in self.jobs:
                    if j.get("status") == "运行中" and j.get("thread_id") == p.get("threadId"):
                        j["note"] = (j.get("note") or "") + "｜已自动拒绝一次审批请求"
                self.save_jobs(); snap = list(self.jobs)
            self.ui("jobs", snap)
        elif m == "_exited":
            if self.client is not None and msg.get("server") is not self.client: return  # 已被替换的旧进程
            with self.jobs_lock:
                hit = [j for j in self.jobs if j.get("status") == "运行中" and j.get("via") != "desktop"]
                for j in hit: j.update(status="结果未知（请检查对话）", last_error="Codex App Server 已退出，本轮可能被中断。", finished_at=time.time())
                if hit: self.save_jobs()
                snap = list(self.jobs); hit = [dict(j) for j in hit]
            if hit: self.ui("jobs", snap)
            for j in hit: self.remote.job_event(j, "done")
    def cancel_job(self):
        sel = self.tree.selection()
        if not sel: self.status.set("请先选择一个任务。"); return
        with self.jobs_lock:
            j = self.find(sel[0])
            if not j: return
            st = j.get("status"); copy = dict(j)
            if st == "待发送": j["status"] = "已取消"; self.save_jobs(); snap = list(self.jobs)
        if st == "待发送": self.render_jobs(snap); self.status.set("已取消任务（重复任务的后续发送也一并停止）。"); return
        if st == "运行中" and copy.get("via") == "desktop": self.status.set("这一轮由 Codex 桌面版执行，如需停止，请在桌面版的该对话里点停止。"); return
        if st != "运行中" or not copy.get("turn_id"): self.status.set("只能取消待发送的任务，或中断运行中的任务。"); return
        if messagebox.askyesno(APP_TITLE, "要中断 Codex 正在执行的这一轮吗？"):
            threading.Thread(target=self.interrupt, args=(copy,), daemon=True).start()
    def interrupt(self, j):
        try: self.ensure_client().request("turn/interrupt", {"threadId": j["thread_id"], "turnId": j["turn_id"]}, 30); self.ui("status", "已请求中断。")
        except Exception as e: self.ui("status", f"中断失败：{e}")
    def clear_jobs(self):
        with self.jobs_lock: self.jobs = [j for j in self.jobs if j.get("status") in ACTIVE]; self.save_jobs(); snap = list(self.jobs)
        self.render_jobs(snap); self.status.set("已清除已结束任务。")
    def show_job(self, _event=None):
        sel = self.tree.selection()
        with self.jobs_lock: j = dict(self.find(sel[0]) or {}) if sel else {}
        if not j: return
        messagebox.showinfo(APP_TITLE, f"计划时间：{stamp(j.get('run_at'))}（{repeat_label(j)}）\n目标对话：{j.get('thread_title')}\n"
                            f"对话 ID：{j.get('thread_id')}\n状态：{j.get('status')}\n说明：{j.get('note') or '—'}\n"
                            f"错误：{j.get('last_error') or '—'}\n\n发送内容：\n{j.get('message')}")
    def load_settings(self):
        try: return json.loads(SETTINGS_FILE.read_text(encoding="utf-8")) if SETTINGS_FILE.exists() else {}
        except Exception: return {}
    def save_settings(self):
        with self.settings_lock:  # 界面和 Telegram 线程都会改设置
            try: SETTINGS_FILE.write_text(json.dumps(self.settings, ensure_ascii=False, indent=2), encoding="utf-8")
            except OSError as e: log("保存设置失败：" + str(e))
    def update_settings(self, **kw):
        with self.settings_lock: self.settings.update(kw)
        self.save_settings()
    def tg_save(self):
        token, proxy = self.tg_token.get().strip(), self.tg_proxy.get().strip()
        if token != (self.settings.get("tg_token") or ""): self.update_settings(tg_chat_id=None, tg_user=None, tg_offset=0)  # 换了机器人要重新绑定
        self.update_settings(tg_token=token, tg_proxy=proxy); self.remote.start()
    def tg_unbind(self):
        if self.settings.get("tg_chat_id") and messagebox.askyesno(APP_TITLE, "解除绑定后，需要在手机上重新发送配对码。确定吗？"): self.remote.unbind()

    # ---------- 给 Telegram 远程控制用 ----------
    def caller_thread(self):
        """桌面版的工具要求以某个真实对话的身份调用。"""
        ids = [v["id"] for v in list(self.threads.values())] + [i for i, _ in self.settings.get("tg_index") or []]
        return ids[0] if ids else None
    def thread_title(self, tid):
        names = {v["id"]: v["title"] for v in list(self.threads.values())}
        names.update({i: t for i, t in self.settings.get("tg_index") or []})
        return names.get(tid) or tid[:8]
    def codex_threads(self):
        """列出 Codex 对话；桌面版开着时带实时状态（工作中 / 空闲）。"""
        caller = self.caller_thread()
        if DesktopTools.available() and caller:
            try:
                r = DesktopTools().call("list_threads", {"limit": 50}, caller)
                return [{"id": t["id"], "title": " ".join((t.get("title") or "未命名对话").split())[:40], "status": t.get("status")}
                        for t in (r.get("pinnedThreads") or []) + (r.get("threads") or []) if t.get("kind") == "codex"]
            except Exception as e: log(f"读取桌面版对话列表失败：{e}")
        return [{"id": t["id"], "title": t["title"][:40], "status": None} for t in self.backend_threads()]
    def last_reply(self, tid, turn_id=None): return last_reply(tid, turn_id)
    def rollout_path(self, tid): return rollout_path(tid)
    def describe_repeat(self, job): return repeat_label(job)
    def add_remote_job(self, tid, title, msg, when, interval=None, times=1):
        repeat = "每隔 N 分钟" if interval and times > 1 else "不重复"
        job = self.new_job({"id": tid, "title": title}, msg, when, repeat, interval if repeat != "不重复" else None,
                           times if repeat != "不重复" else None, remember=False)
        job["source"] = "telegram"
        with self.jobs_lock: self.jobs.append(job); self.save_jobs(); snap = list(self.jobs)
        self.ui("jobs", snap); return job
    def active_jobs(self):
        with self.jobs_lock: return sorted((dict(j) for j in self.jobs if j.get("status") in ACTIVE), key=lambda x: float(x.get("run_at", 0)))
    def cancel_pending(self, jid):
        with self.jobs_lock:
            j = self.find(jid)
            if not j: return "找不到这个任务（可能已经被清除）。"
            if j.get("status") == "运行中": return "这个任务已经发出去了，Codex 正在执行。要停止请在电脑上的 Codex 里点停止。"
            if j.get("status") != "待发送": return f"这个任务现在是“{j.get('status')}”，不能取消。"
            j["status"] = "已取消"; self.save_jobs(); snap = list(self.jobs); title = j.get("thread_title")
        self.ui("jobs", snap); return f"已取消发送到「{title}」的任务。"
    def load_jobs(self):
        try:
            if JOBS_FILE.exists():
                raw = json.loads(JOBS_FILE.read_text(encoding="utf-8")); self.jobs = raw if isinstance(raw, list) else []
                for j in self.jobs:
                    if j.get("status") == "发送中":
                        j["status"] = "结果未知（请检查对话）"; j["last_error"] = "程序关闭时正在发送；为避免重复，不会自动重试。"
                    elif j.get("status") == "运行中" and j.get("via") != "desktop":  # 桌面版执行的任务不受本程序重启影响，继续查询结果
                        j["status"] = "结果未知（请检查对话）"; j["last_error"] = "程序关闭时 Codex 仍在执行，本轮可能已被中断。"
                self.save_jobs()
        except Exception as e: log("读取任务文件失败：" + str(e)); self.jobs = []
    def save_jobs(self):
        try:
            tmp = JOBS_FILE.with_suffix(".tmp"); tmp.write_text(json.dumps(self.jobs, ensure_ascii=False, indent=2), encoding="utf-8"); tmp.replace(JOBS_FILE)
        except Exception as e: log("保存任务失败：" + str(e))
    def render_jobs(self, jobs):
        for row in self.tree.get_children(): self.tree.delete(row)
        for j in sorted(jobs, key=lambda x: float(x.get("run_at", 0))):
            msg = " ".join(str(j.get("message", "")).split())
            self.tree.insert("", "end", iid=j["id"], values=(stamp(j.get("run_at")), repeat_label(j), j.get("thread_title", j.get("thread_id", "")),
                             msg, j.get("status", ""), j.get("last_error") or j.get("note") or ""))
    def close(self):
        with self.jobs_lock:
            running = sum(j.get("status") in ("发送中", "运行中") and j.get("via") != "desktop" for j in self.jobs); pending = sum(j.get("status") == "待发送" for j in self.jobs)
        if running and not messagebox.askyesno(APP_TITLE, "Codex 正在执行定时发送的任务，退出程序会中断它。\n\n确定退出吗？"): return
        if not running and pending and not messagebox.askyesno(APP_TITLE, f"还有 {pending} 个待发送任务，退出后它们不会准时发送。\n\n"
                                                               "确定退出吗？（想让它在后台等着，请点“否”，然后把窗口最小化。）"): return
        self.stop.set(); self.remote.shutdown()
        with self.client_lock: c, self.client = self.client, None
        if c: c.close()
        self.root.destroy()

def main():
    if not single_instance():
        r = tk.Tk(); r.withdraw(); messagebox.showinfo(APP_TITLE, "程序已经在运行了（可能最小化在任务栏里）。"); r.destroy(); return
    root = tk.Tk()
    try: ttk.Style().theme_use("vista")
    except Exception: pass
    App(root, minimized="--minimized" in sys.argv); root.mainloop()
if __name__ == "__main__": main()
