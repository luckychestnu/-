@echo off
cd /d "%~dp0"
where pythonw >nul 2>nul && (start "" pythonw "%~dp0codex_scheduled_continue.py" & exit /b 0)
where pyw >nul 2>nul && (start "" pyw "%~dp0codex_scheduled_continue.py" & exit /b 0)
python "%~dp0codex_scheduled_continue.py"
if errorlevel 1 pause
