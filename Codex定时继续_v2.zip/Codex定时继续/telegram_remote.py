# -*- coding: utf-8 -*-
"""Telegram 远程控制：在手机上给 Codex 对话下指令，并把 Codex 的输出发回手机。

只接受已绑定账号的私聊消息；绑定需要电脑上程序窗口里显示的配对码。"""
from __future__ import annotations
import datetime as dt, json, os, re, secrets, threading, time, urllib.error, urllib.request, uuid

API = "https://api.telegram.org/bot{}/{}"
CHUNK = 3900            # 单条消息上限 4096 字，留点余量
MAX_CHUNKS = 3          # 超过这么多条就改为发 txt 文件
WATCH_LIMIT = 20        # 最多同时关注的对话数
WATCH_POLL = 3          # 每隔几秒检查一次被关注对话的记录文件
STATUS = {"active": "工作中", "systemError": "出错停止"}
COMMANDS = [("list", "列出 Codex 对话和状态"), ("send", "定时发送：/send 对话 时间 [间隔 次数] 内容"),
            ("msg", "发送：/msg 对话 [时间 间隔 次数] 内容，不写时间=立即"),
            ("tasks", "查看任务"), ("cancel", "取消任务：/cancel 任务号"), ("watch", "关注对话的输出：/watch 对话"),
            ("unwatch", "取消关注：/unwatch 对话"), ("last", "最后一条回复：/last 对话"), ("help", "查看帮助")]
HELP = ("指令（对话用 /list 里的编号指定）：\n"
        "/list — 列出 Codex 对话和状态\n"
        "/send 2 05:30 继续 — 定时发送\n"
        "/msg 2 继续 — 立即发送；也可以带时间：/msg 2 05:30 继续\n"
        "    时间：05:30（已过就是明天）、2026-10-22 05:30、+30m、+2h、now\n"
        "    重复：时间后面加“间隔 次数”，例如\n"
        "    /send 2 05:30 30m x3 继续 → 05:30、06:00、06:30 各发一次\n"
        "    间隔可写 30m、2h、1h30m、1d；次数写成 x3，不写就是 1 次\n"
        "/tasks — 查看待发送 / 进行中的任务\n"
        "/cancel 1 — 取消 /tasks 里的 1 号任务（重复任务的后续也一起取消）\n"
        "/watch 2 — 关注对话：它每跑完一轮就把结果发给你（不带编号 = 查看已关注）\n"
        "/unwatch 2 — 取消关注\n"
        "/last 2 — 发来最后一条回复\n"
        "直接“回复”某条 Codex 通知 — 把你写的内容发到那个对话\n\n"
        "Codex 正在工作时，消息会等它停下来再发。定时任务发出的那一轮跑完，会自动通知你。")
CMD_RE = re.compile(r"^/(\w+)(?:@\w+)?(?:\s+(.*))?$", re.S)
TIME_RE = re.compile(r"^(\d{1,2}):(\d{2})(?::(\d{2}))?$")
DATE_RE = re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})$")
REL_RE = re.compile(r"^\+(?:(\d+)h)?(?:(\d+)m)?$", re.I)
INTERVAL_RE = re.compile(r"^(?:(\d+)d)?(?:(\d+)h)?(?:(\d+)m)?$", re.I)
COUNT_RE = re.compile(r"^[x×*](\d+)$", re.I)

class TelegramError(Exception):
    def __init__(self, desc, code=None): super().__init__(desc); self.code = code

class TelegramAPI:
    """Telegram 官方机器人接口。不填代理时沿用 Windows 系统代理。"""
    def __init__(self, token, proxy=""):
        self.token = token
        self.opener = urllib.request.build_opener(*([urllib.request.ProxyHandler({"http": proxy, "https": proxy})] if proxy else []))
    def _open(self, req, timeout):
        try:
            with self.opener.open(req, timeout=timeout) as r: body = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try: body = json.loads(e.read().decode("utf-8"))
            except Exception: raise TelegramError(f"HTTP {e.code}", e.code) from None
        if not body.get("ok"): raise TelegramError(body.get("description") or "未知错误", body.get("error_code"))
        return body.get("result")
    def call(self, method, params=None, timeout=30):
        req = urllib.request.Request(API.format(self.token, method), data=json.dumps(params or {}).encode("utf-8"),
                                     headers={"Content-Type": "application/json"})
        return self._open(req, timeout)
    def send_document(self, chat_id, name, data, caption=""):
        boundary = uuid.uuid4().hex; parts = []
        for k, v in {"chat_id": str(chat_id), "caption": caption[:1000]}.items():
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode("utf-8"))
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{name}"\r\n'
                     f'Content-Type: text/plain; charset=utf-8\r\n\r\n'.encode("utf-8") + data + b"\r\n")
        parts.append(f"--{boundary}--\r\n".encode("utf-8"))
        req = urllib.request.Request(API.format(self.token, "sendDocument"), data=b"".join(parts),
                                     headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
        return self._open(req, 60)

def head(text):
    """拆出第一个词，返回 (词, 剩下的原文)；剩下的部分保留换行。"""
    parts = text.split(None, 1)
    return (parts[0], parts[1] if len(parts) > 1 else "") if parts else ("", "")

def parse_spec(text, need_time=True, now=None):
    """解析“[时间] [间隔] [次数] 内容”，返回 (第一次的时间戳, 间隔分钟或 None, 一共几次, 内容)。
    时间：now、+30m、+2h、05:30、2026-10-22 05:30；间隔：30m、2h、1h30m、1d；次数：x3。"""
    now = time.time() if now is None else now
    tok, after = head(text); when = None
    rel = REL_RE.match(tok)
    if DATE_RE.match(tok):
        tok2, rest = head(after)
        if not TIME_RE.match(tok2): raise ValueError(f"日期“{tok}”后面要跟时间，例如 {tok} 05:30")
        try: day = dt.date(*map(int, DATE_RE.match(tok).groups()))
        except ValueError: raise ValueError(f"日期“{tok}”不对。") from None
        when, after = clock(tok2, day), rest
    elif tok.lower() == "now": when = now
    elif rel and (rel.group(1) or rel.group(2)): when = now + int(rel.group(1) or 0) * 3600 + int(rel.group(2) or 0) * 60
    elif TIME_RE.match(tok):
        when = clock(tok, dt.date.fromtimestamp(now))
        if when <= now: when = clock(tok, dt.date.fromtimestamp(now) + dt.timedelta(days=1))  # 今天已经过了就是明天
    if when is None:
        if need_time: raise ValueError(f"看不懂时间“{tok}”。可以写 05:30、2026-10-22 05:30、+30m、+2h 或 now。")
        when, after = now, text  # 没写时间：立即发送，整段都是后面的内容
    interval, times = None, 1
    tok, rest = head(after); m = INTERVAL_RE.match(tok)
    if tok and m and any(m.groups()):
        interval = int(m.group(1) or 0) * 1440 + int(m.group(2) or 0) * 60 + int(m.group(3) or 0); after = rest
        if interval < 1: raise ValueError("间隔至少 1 分钟。")
    tok, rest = head(after); m = COUNT_RE.match(tok)
    if m:
        times, after = int(m.group(1)), rest
        if not 1 <= times <= 1000: raise ValueError("次数要在 1 到 1000 之间。")
        if times > 1 and not interval: raise ValueError("设置了次数，还要设置间隔，例如 05:30 30m x3 继续（每 30 分钟一次，共 3 次）")
    content = after.strip()
    if not content: raise ValueError("缺少要发送的内容。例如：/send 2 05:30 继续")
    if when < now - 60: raise ValueError("这个时间已经过去了。")
    return when, interval, times, content

def clock(tok, day):
    h, m, s = TIME_RE.match(tok).groups()
    try: return dt.datetime.combine(day, dt.time(int(h), int(m), int(s or 0))).timestamp()
    except ValueError: raise ValueError(f"时间“{tok}”不对。") from None

def split_text(text):
    chunks = []
    while len(text) > CHUNK:
        cut = text.rfind("\n", 0, CHUNK)
        cut = cut if cut > CHUNK // 2 else CHUNK
        chunks.append(text[:cut]); text = text[cut:].lstrip("\n")
    return chunks + [text]

def short(text, n=60):
    text = " ".join(str(text).split())
    return text if len(text) <= n else text[:n] + "…"

def fmt(ts): return dt.datetime.fromtimestamp(float(ts)).strftime("%m-%d %H:%M")

def span(minutes):
    n = int(minutes)
    if n % 1440 == 0: return f"{n // 1440} 天"
    if n % 60 == 0: return f"{n // 60} 小时"
    return f"{n // 60} 小时 {n % 60} 分钟" if n > 60 else f"{n} 分钟"

class TelegramRemote:
    def __init__(self, app, log):
        self.app, self.log = app, log
        self.api = None; self.gen = 0; self.stop = threading.Event(); self.lock = threading.Lock()
        self.pair_code = self.new_code(); self.bad_binds = 0; self.bot_name = ""
        self.notified = set()  # 已经推送过的 Codex 轮次，避免“关注”和“任务完成”重复通知
        self.pos_lock = threading.Lock()
        self.task_index = []
    @property
    def settings(self): return self.app.settings
    @property
    def chat_id(self): return self.settings.get("tg_chat_id")
    @property
    def thread_index(self): return self.settings.get("tg_index") or []
    @staticmethod
    def new_code(): return f"{secrets.randbelow(10 ** 6):06d}"
    def status(self, text): self.app.ui("tg", text)
    def clean(self, e): return str(e).replace(self.api.token, "***") if self.api else str(e)
    def start(self):
        self.gen += 1; gen = self.gen
        token = (self.settings.get("tg_token") or "").strip()
        if not token:
            self.api = None; self.status("未设置。在 Telegram 里找 @BotFather 发送 /newbot 创建机器人，把它给的令牌填到上面，点“保存并连接”。"); return
        self.api = TelegramAPI(token, (self.settings.get("tg_proxy") or "").strip()); self.bot_name = ""
        self.status("正在连接 Telegram…")
        threading.Thread(target=self.poll_loop, args=(gen, self.api), daemon=True).start()
        threading.Thread(target=self.watch_loop, args=(gen,), daemon=True).start()
    def shutdown(self): self.gen += 1; self.stop.set()
    def alive(self, gen): return gen == self.gen and not self.stop.is_set()
    def show_ready(self):
        if self.chat_id: self.status(f"已连接 @{self.bot_name}，已绑定 {self.settings.get('tg_user') or '你的账号'}。在手机上给机器人发 /help 查看指令。")
        else: self.status(f"已连接 @{self.bot_name}，等待绑定：请在 Telegram 里给机器人发送   /bind {self.pair_code}")
    def unbind(self):
        self.app.update_settings(tg_chat_id=None, tg_user=None); self.pair_code = self.new_code()
        if self.bot_name: self.show_ready()

    # ---------- 接收指令 ----------
    def poll_loop(self, gen, api):
        backoff = 5
        while self.alive(gen):
            try:
                if not self.bot_name:
                    self.bot_name = api.call("getMe")["username"]
                    api.call("setMyCommands", {"commands": [{"command": c, "description": d} for c, d in COMMANDS]})
                    self.show_ready(); self.log(f"Telegram 已连接：@{self.bot_name}")
                updates = api.call("getUpdates", {"offset": self.settings.get("tg_offset", 0), "timeout": 50,
                                                  "allowed_updates": ["message"]}, timeout=70)
                backoff = 5
                for u in updates:
                    if not self.alive(gen): return
                    self.app.update_settings(tg_offset=u["update_id"] + 1)  # 先记下进度：某条消息处理出错也不会反复重来
                    try: self.handle(u.get("message") or {})
                    except Exception as e: self.log(f"处理 Telegram 消息出错：{self.clean(e)}")
            except TelegramError as e:
                if e.code == 401: self.status("机器人令牌无效，请检查后重新填写。"); return
                if e.code == 409: self.status("这个机器人正被另一个程序使用（或设置了 webhook），请先关掉那个程序。")
                self.log(f"Telegram 出错：{self.clean(e)}"); self.stop.wait(backoff); backoff = min(backoff * 2, 60)
            except Exception as e:
                if not self.alive(gen): return
                self.bot_name = ""; self.status(f"连不上 Telegram，请检查代理是否开启（{backoff} 秒后重试）：{self.clean(e)}")
                self.stop.wait(backoff); backoff = min(backoff * 2, 60)
    def handle(self, msg):
        chat = msg.get("chat") or {}; text = (msg.get("text") or "").strip()
        if chat.get("type") != "private" or not text: return
        cid = chat["id"]; m = CMD_RE.match(text)
        cmd, rest = (m.group(1).lower(), (m.group(2) or "").strip()) if m else ("", text)
        if not self.chat_id:
            if cmd == "bind": self.bind(cid, msg, rest)
            elif cmd in ("start", "help"): self.send("这个机器人还没有绑定。请在电脑上的“Codex 定时继续”窗口里查看配对码，然后发送 /bind 配对码。", chat_id=cid)
            return
        if cid != self.chat_id: return  # 只听绑定账号的指令，其他人一律不理
        age = time.time() - float(msg.get("date") or time.time())
        note = f"（这条指令是 {int(age // 60)} 分钟前发的）\n" if age > 300 else ""
        try:
            if not cmd:
                tid = (self.settings.get("tg_msgmap") or {}).get(str((msg.get("reply_to_message") or {}).get("message_id")))
                if tid:  # 回复通知：原样立即发送，不解析时间
                    title = self.app.thread_title(tid); self.app.add_remote_job(tid, title, text, time.time())
                    return self.send(note + f"马上发送到「{title}」：{short(text)}")
                return self.send("要发给 Codex 的话，请用 /msg 对话号 内容，或者直接“回复”某条 Codex 通知。发送 /help 查看全部指令。")
            handler = {"start": self.cmd_help, "help": self.cmd_help, "list": self.cmd_list, "send": self.cmd_send, "msg": self.cmd_msg,
                       "tasks": self.cmd_tasks, "cancel": self.cmd_cancel, "watch": self.cmd_watch, "unwatch": self.cmd_unwatch,
                       "last": self.cmd_last, "bind": lambda r, n: self.send("已经绑定过了。")}.get(cmd)
            if not handler: return self.send(f"不认识的指令 /{cmd}。发送 /help 查看全部指令。")
            handler(rest, note)
        except ValueError as e: self.send(str(e))
    def bind(self, cid, msg, code):
        if code.strip() == self.pair_code:
            u = msg.get("from") or {}
            name = "@" + u["username"] if u.get("username") else (u.get("first_name") or str(cid))
            self.app.update_settings(tg_chat_id=cid, tg_user=name)
            self.send("绑定成功！以后这个机器人只听你的指令。\n\n" + HELP); self.show_ready(); self.log(f"Telegram 已绑定：{name}")
        else:
            self.bad_binds += 1
            if self.bad_binds >= 5: self.pair_code = self.new_code(); self.bad_binds = 0; self.show_ready()  # 防止被人猜
            self.send("配对码不对。请看电脑上程序窗口里显示的 6 位数字。", chat_id=cid)
    def cmd_help(self, rest, note): self.send(HELP)
    def cmd_list(self, rest, note):
        threads = self.app.codex_threads()
        if not threads: return self.send("没有找到 Codex 对话。")
        self.app.update_settings(tg_index=[[t["id"], t["title"]] for t in threads])
        watched = set(self.settings.get("tg_watch") or [])
        lines = [f"{i}. {t['title']}  [{STATUS.get(t.get('status'), '空闲')}]" + ("  👁" if t["id"] in watched else "")
                 for i, t in enumerate(threads, 1)]
        self.send(note + "Codex 对话（编号用于其他指令，👁 = 已关注）：\n" + "\n".join(lines))
    def resolve(self, ref):
        if not ref: raise ValueError("请指定对话编号（先发 /list 查看）。")
        index = self.thread_index
        if not index:
            index = [[t["id"], t["title"]] for t in self.app.codex_threads()]; self.app.update_settings(tg_index=index)
        if ref.isdigit():
            n = int(ref)
            if 1 <= n <= len(index): return tuple(index[n - 1])
            raise ValueError(f"没有 {n} 号对话，先发 /list 看看编号。")
        hits = [x for x in index if x[0].startswith(ref) or ref.lower() in x[1].lower()]
        if len(hits) == 1: return tuple(hits[0])
        raise ValueError(f"找不到唯一匹配“{ref}”的对话，请先发 /list，再用编号指定。")
    def cmd_send(self, rest, note):
        parts = rest.split(None, 1)
        if len(parts) < 2: raise ValueError("格式：/send 对话号 时间 内容，例如 /send 2 05:30 继续")
        tid, title = self.resolve(parts[0]); self.queue(tid, title, parts[1], note, need_time=True)
    def cmd_msg(self, rest, note):
        parts = rest.split(None, 1)
        if len(parts) < 2: raise ValueError("格式：/msg 对话号 [时间] 内容，例如 /msg 2 继续 或 /msg 2 05:30 继续")
        tid, title = self.resolve(parts[0]); self.queue(tid, title, parts[1], note, need_time=False)
    def queue(self, tid, title, text, note, need_time):
        when, interval, times, content = parse_spec(text, need_time)
        self.app.add_remote_job(tid, title, content, when, interval, times)
        lead = "马上发送到" if when <= time.time() + 5 else f"已安排在 {fmt(when)} 发送到"
        extra = ""
        if times > 1:
            plan = [fmt(when + k * interval * 60) for k in range(min(times, 4))] + (["…"] if times > 4 else [])
            extra = f"\n每 {span(interval)}一次，共 {times} 次（预计 {'、'.join(plan)}）"
        elif interval: extra = "\n（只发 1 次。要重复发送请加次数，例如 30m x3）"
        self.send(note + f"{lead}「{title}」：{short(content)}{extra}")
    def cmd_tasks(self, rest, note):
        jobs = self.app.active_jobs()
        if not jobs: self.task_index = []; return self.send("现在没有待发送或进行中的任务。")
        self.task_index = [j["id"] for j in jobs]
        rep = lambda j: "" if (j.get("repeat") or "不重复") == "不重复" else f"（{self.app.describe_repeat(j)}）"
        lines = [f"{i}. {fmt(j['run_at'])} →「{j.get('thread_title')}」：{short(j.get('message'), 30)}{rep(j)}  [{j.get('status')}]"
                 + (f"\n    {short(j['note'], 80)}" if j.get("note") else "") for i, j in enumerate(jobs, 1)]
        self.send("任务（用 /cancel 编号 取消）：\n" + "\n".join(lines))
    def cmd_cancel(self, rest, note):
        if not rest.isdigit() or not 1 <= int(rest) <= len(self.task_index): raise ValueError("请先发 /tasks，再用 /cancel 编号 取消。")
        self.send(self.app.cancel_pending(self.task_index[int(rest) - 1]))
    def cmd_watch(self, rest, note):
        watched = list(self.settings.get("tg_watch") or [])
        if not rest:
            names = [f"• {self.app.thread_title(t)}" for t in watched]
            return self.send("正在关注：\n" + "\n".join(names) if names else "还没有关注任何对话。用 /watch 对话号 关注。")
        tid, title = self.resolve(rest)
        if tid in watched: return self.send(f"已经在关注「{title}」了。")
        if len(watched) >= WATCH_LIMIT: raise ValueError(f"最多同时关注 {WATCH_LIMIT} 个对话，请先 /unwatch 一个。")
        self.mark_start(tid); self.app.update_settings(tg_watch=watched + [tid])
        self.send(f"已关注「{title}」：它每跑完一轮，都会把结果发给你。")
    def cmd_unwatch(self, rest, note):
        tid, title = self.resolve(rest)
        watched = [t for t in self.settings.get("tg_watch") or [] if t != tid]
        self.app.update_settings(tg_watch=watched); self.send(f"已取消关注「{title}」。")
    def cmd_last(self, rest, note):
        tid, title = self.resolve(rest)
        text = self.app.last_reply(tid)
        self.send(f"「{title}」的最后一条回复：\n\n{text}" if text else f"「{title}」还没有回复。", tid)

    # ---------- 发送通知 ----------
    def send(self, text, thread_id=None, chat_id=None):
        """发消息给手机；带 thread_id 的消息，用户“回复”它时会转发到该 Codex 对话。"""
        api, chat_id = self.api, chat_id or self.chat_id
        if not api or not chat_id: return
        try:
            ids, chunks = [], split_text(text)
            opts = {"chat_id": chat_id, "link_preview_options": {"is_disabled": True}}
            if len(chunks) > MAX_CHUNKS:
                ids.append(api.call("sendMessage", {**opts, "text": chunks[0] + "\n\n（内容较长，完整内容见下面的文件）"})["message_id"])
                ids.append(api.send_document(chat_id, "codex-reply.txt", text.encode("utf-8"), "完整内容")["message_id"])
            else:
                for c in chunks: ids.append(api.call("sendMessage", {**opts, "text": c})["message_id"])
            if thread_id:
                mp = dict(self.settings.get("tg_msgmap") or {}); mp.update({str(i): thread_id for i in ids})
                self.app.update_settings(tg_msgmap=dict(list(mp.items())[-300:]))
        except Exception as e: self.log(f"发送 Telegram 消息失败：{self.clean(e)}")
    def job_event(self, job, kind, turn_id=None):
        """定时任务状态变化时通知手机（放到线程里，不拖慢调度）。"""
        if self.api and self.chat_id: threading.Thread(target=self._job_event, args=(job, kind, turn_id), daemon=True).start()
    def _job_event(self, job, kind, turn_id):
        title, tid, st = job.get("thread_title"), job.get("thread_id"), job.get("status")
        if kind == "waiting": text = f"⏳「{title}」还在工作，等它停下来再发（每 5 分钟检查一次）：{short(job.get('message'))}"
        elif kind == "sent":
            rep = "" if (job.get("repeat") or "不重复") == "不重复" else f"（{self.app.describe_repeat(job)}）"
            text = f"▶️ 已发送到「{title}」{rep}：{short(job.get('message'))}\nCodex 开始工作，跑完会通知你。"
        elif st == "已完成":
            if not self.claim(turn_id): return  # 已经由“关注”推送过
            text = f"✅「{title}」完成了。\n\n{self.app.last_reply(tid, turn_id) or '（没有读到回复文本）'}"
        elif st == "失败": text = f"❌「{title}」失败：{job.get('last_error') or '未知原因'}"
        else: text = f"⚠️「{title}」{st}：{job.get('last_error') or job.get('note') or ''}"
        self.send(text, tid)
    def claim(self, turn_id):
        if not turn_id: return True
        with self.lock:
            if turn_id in self.notified: return False
            self.notified.add(turn_id); return True

    # ---------- 关注对话 ----------
    def watch_loop(self, gen):
        """每隔几秒看一眼被关注对话的本地记录文件，有新的一轮结束就推送。只读文件，桌面版开不开都能用。"""
        while self.alive(gen):
            if self.api and self.chat_id:
                for tid in list(self.settings.get("tg_watch") or []):
                    try: self.scan(tid)
                    except Exception as e: self.log(f"读取关注对话的记录出错：{e}")
            self.stop.wait(WATCH_POLL)
    def mark_start(self, tid):
        """从现在开始关注：记下记录文件当前的长度，之前的轮次不推送。"""
        path = self.app.rollout_path(tid)
        with self.pos_lock:
            pos = dict(self.settings.get("tg_pos") or {}); pos[tid] = os.path.getsize(path) if path else 0
            self.app.update_settings(tg_pos=pos)
    def scan(self, tid):
        path = self.app.rollout_path(tid)
        if not path: return
        size = os.path.getsize(path)
        with self.pos_lock:
            pos = dict(self.settings.get("tg_pos") or {}); off = pos.get(tid)
            if off is None or off > size:  # 第一次看到，或文件被重写过：从当前末尾开始
                pos[tid] = size; self.app.update_settings(tg_pos=pos); return
        if off == size: return
        with open(path, "rb") as f: f.seek(off); data = f.read(size - off)
        end = data.rfind(b"\n") + 1  # 只处理写完整的行，没写完的留到下次
        if not end: return
        with self.pos_lock:
            pos = dict(self.settings.get("tg_pos") or {}); pos[tid] = off + end; self.app.update_settings(tg_pos=pos)
        for line in data[:end].decode("utf-8", "replace").splitlines():
            if '"task_complete"' not in line and '"turn_aborted"' not in line: continue
            try: o = json.loads(line)
            except ValueError: continue
            pl = o.get("payload") or {}
            if o.get("type") == "event_msg" and pl.get("type") in ("task_complete", "turn_aborted"): self.turn_done(tid, pl)
    def turn_done(self, tid, pl):
        if not self.claim(pl.get("turn_id")): return  # 已经由“任务完成”推送过
        title, err = self.app.thread_title(tid), pl.get("error")
        err = (err.get("message") if isinstance(err, dict) else err) or ""
        if pl.get("type") == "turn_aborted": self.send(f"⚠️「{title}」这一轮被中断了。", tid)
        elif err: self.send(f"❌「{title}」这一轮失败：{err}", tid)
        else: self.send(f"✅「{title}」跑完了一轮。\n\n{pl.get('last_agent_message') or '（没有回复文本）'}", tid)
