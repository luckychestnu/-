//go:build windows

// Campus Network Keepalive GUI - native Windows application, standard library only.
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const (
	WS_OVERLAPPEDWINDOW = 0x00CF0000
	WS_VISIBLE          = 0x10000000
	WS_CHILD            = 0x40000000
	WS_TABSTOP          = 0x00010000
	WS_VSCROLL          = 0x00200000
	WS_BORDER           = 0x00800000
	WS_CLIPCHILDREN     = 0x02000000
	ES_LEFT             = 0
	ES_AUTOHSCROLL      = 0x0080
	ES_MULTILINE        = 4
	ES_AUTOVSCROLL      = 0x0040
	ES_READONLY         = 0x0800
	ES_NUMBER           = 0x2000
	BS_PUSHBUTTON       = 0
	BS_AUTOCHECKBOX     = 3
	CBS_DROPDOWNLIST    = 3
	CBS_HASSTRINGS      = 0x0200
	SS_LEFT             = 0
	WS_EX_CLIENTEDGE    = 0x00000200
	WM_CREATE           = 1
	WM_DESTROY          = 2
	WM_SIZE             = 5
	WM_CLOSE            = 16
	WM_PAINT            = 15
	WM_ERASEBKGND       = 20
	WM_COMMAND          = 0x0111
	WM_TIMER            = 0x0113
	WM_CTLCOLORSTATIC   = 0x0138
	WM_CTLCOLOREDIT     = 0x0133
	WM_SETFONT          = 0x0030
	WM_GETTEXT          = 0x000D
	WM_GETTEXTLENGTH    = 0x000E
	WM_SETTEXT          = 0x000C
	BM_GETCHECK         = 0x00F0
	BM_SETCHECK         = 0x00F1
	BST_CHECKED         = 1
	CB_ADDSTRING        = 0x0143
	CB_GETCURSEL        = 0x0147
	CB_SETCURSEL        = 0x014E
	EM_SETSEL           = 0x00B1
	EM_REPLACESEL       = 0x00C2
	EN_CHANGE           = 0x0300
	BN_CLICKED          = 0
	CBN_SELCHANGE       = 1
	SW_SHOW             = 5
	SW_HIDE             = 0
	IDC_ARROW           = 32512
	IDI_APPLICATION     = 32512
	TRANSPARENT         = 1
)
const (
	idStatus       = 101
	idLast         = 102
	idNext         = 103
	idCount        = 104
	idPresetEco    = 110
	idPresetNormal = 111
	idPresetFast   = 112
	idPresetHint   = 113
	idInterval     = 120
	idTimeout      = 121
	idTarget       = 122
	idURL          = 123
	idBypass       = 124
	idAwake        = 125
	idLogging      = 126
	idStartup      = 127
	idAutoRun      = 128
	idStart        = 130
	idStop         = 131
	idTest         = 132
	idSave         = 133
	idOpenLog      = 134
	idLog          = 140
	idFooter       = 141
)

type rect struct{ Left, Top, Right, Bottom int32 }
type point struct{ X, Y int32 }
type msg struct {
	Hwnd           uintptr
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             point
	LPrivate       uint32
}
type wndClass struct {
	Size, Style                        uint32
	WndProc                            uintptr
	ClsExtra, WndExtra                 int32
	Instance, Icon, Cursor, Background uintptr
	MenuName, ClassName                *uint16
	IconSm                             uintptr
}
type paintStruct struct {
	Hdc                uintptr
	Erase              int32
	Paint              rect
	Restore, IncUpdate int32
	Reserved           [32]byte
}
type minMaxInfo struct {
	Reserved     point
	MaxSize      point
	MaxPosition  point
	MinTrackSize point
	MaxTrackSize point
}

var user32 = syscall.NewLazyDLL("user32.dll")
var gdi32 = syscall.NewLazyDLL("gdi32.dll")
var kernel32 = syscall.NewLazyDLL("kernel32.dll")
var advapi32 = syscall.NewLazyDLL("advapi32.dll")
var pRegisterClassEx = user32.NewProc("RegisterClassExW")
var pCreateWindow = user32.NewProc("CreateWindowExW")
var pDefWindowProc = user32.NewProc("DefWindowProcW")
var pShowWindow = user32.NewProc("ShowWindow")
var pUpdateWindow = user32.NewProc("UpdateWindow")
var pGetMessage = user32.NewProc("GetMessageW")
var pTranslateMessage = user32.NewProc("TranslateMessage")
var pDispatchMessage = user32.NewProc("DispatchMessageW")
var pPostQuitMessage = user32.NewProc("PostQuitMessage")
var pSendMessage = user32.NewProc("SendMessageW")
var pSetWindowText = user32.NewProc("SetWindowTextW")
var pGetDlgCtrlID = user32.NewProc("GetDlgCtrlID")
var pDestroyWindow = user32.NewProc("DestroyWindow")
var pEnableWindow = user32.NewProc("EnableWindow")
var pGetWindowText = user32.NewProc("GetWindowTextW")
var pGetWindowTextLen = user32.NewProc("GetWindowTextLengthW")
var pSetTimer = user32.NewProc("SetTimer")
var pKillTimer = user32.NewProc("KillTimer")
var pMessageBox = user32.NewProc("MessageBoxW")
var pLoadCursor = user32.NewProc("LoadCursorW")
var pLoadIcon = user32.NewProc("LoadIconW")
var pBeginPaint = user32.NewProc("BeginPaint")
var pEndPaint = user32.NewProc("EndPaint")
var pGetClientRect = user32.NewProc("GetClientRect")
var pMoveWindow = user32.NewProc("MoveWindow")
var pInvalidateRect = user32.NewProc("InvalidateRect")
var pSetTextColor = gdi32.NewProc("SetTextColor")
var pSetBkMode = gdi32.NewProc("SetBkMode")
var pSetBkColor = gdi32.NewProc("SetBkColor")
var pCreateSolidBrush = gdi32.NewProc("CreateSolidBrush")
var pFillRect = user32.NewProc("FillRect")
var pCreateFont = gdi32.NewProc("CreateFontW")
var pSelectObject = gdi32.NewProc("SelectObject")
var pRoundRect = gdi32.NewProc("RoundRect")
var pCreatePen = gdi32.NewProc("CreatePen")
var pDeleteObject = gdi32.NewProc("DeleteObject")
var pSetThreadExec = kernel32.NewProc("SetThreadExecutionState")
var pRegCreateKey = advapi32.NewProc("RegCreateKeyExW")
var pRegSetValue = advapi32.NewProc("RegSetValueExW")
var pRegDelValue = advapi32.NewProc("RegDeleteValueW")
var pRegCloseKey = advapi32.NewProc("RegCloseKey")
var pGetModuleHandle = kernel32.NewProc("GetModuleHandleW")
var pCreateMutex = kernel32.NewProc("CreateMutexW")
var pCloseHandle = kernel32.NewProc("CloseHandle")

func u16(s string) *uint16     { return syscall.StringToUTF16Ptr(s) }
func cref(r, g, b int) uintptr { return uintptr(r | (g << 8) | (b << 16)) }
func lo(v uintptr) int         { return int(v & 0xffff) }
func hi(v uintptr) int         { return int((v >> 16) & 0xffff) }
func msgSend(hwnd uintptr, message uint32, w, l uintptr) uintptr {
	v, _, _ := pSendMessage.Call(hwnd, uintptr(message), w, l)
	return v
}
func winText(hwnd uintptr, s string) { pSetWindowText.Call(hwnd, uintptr(unsafe.Pointer(u16(s)))) }
func enable(hwnd uintptr, v bool) {
	var n uintptr
	if v {
		n = 1
	}
	pEnableWindow.Call(hwnd, n)
}
func checked(hwnd uintptr) bool { return msgSend(hwnd, BM_GETCHECK, 0, 0) == BST_CHECKED }
func setCheck(hwnd uintptr, b bool) {
	var n uintptr
	if b {
		n = BST_CHECKED
	}
	msgSend(hwnd, BM_SETCHECK, n, 0)
}
func ctrlText(hwnd uintptr) string {
	n, _, _ := pGetWindowTextLen.Call(hwnd)
	buf := make([]uint16, n+2)
	pGetWindowText.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	return syscall.UTF16ToString(buf)
}
func pick(i int) int { return i }

var hwndMain uintptr
var ctrls = map[int]uintptr{}
var fontBody, fontSmall, fontBig, fontSemi uintptr
var brushBG, brushWhite uintptr
var saved config
var cfgFile, logFile string
var isRunning, isBusy bool
var nextDue time.Time
var lastAwake time.Time
var successes, failures int
var taskSeq int
var onDemand bool
var currentPreset = "均衡（推荐）"
var statusLevel = 0
var clientHeight = 730
var resultCh = make(chan probeResult, 8)
var currentCancel context.CancelFunc

type config struct {
	IntervalSec      int    `json:"interval_seconds"`
	TimeoutSec       int    `json:"timeout_seconds"`
	Target           int    `json:"target"`
	CustomURL        string `json:"custom_url"`
	BypassProxy      bool   `json:"bypass_proxy"`
	PreventSleep     bool   `json:"prevent_sleep"`
	WriteLog         bool   `json:"write_log"`
	StartWithWindows bool   `json:"start_with_windows"`
	AutoRun          bool   `json:"auto_start_on_launch"`
}
type probeResult struct {
	seq     int
	at      time.Time
	success bool
	detail  string
	err     string
}

func defaultCfg() config {
	return config{IntervalSec: 180, TimeoutSec: 10, Target: 0, CustomURL: "https://example.com/", BypassProxy: true, PreventSleep: false, WriteLog: true}
}
func dataDir() string {
	p := os.Getenv("LOCALAPPDATA")
	if p == "" {
		p = os.TempDir()
	}
	return filepath.Join(p, "CampusKeepAliveGUI")
}
func loadConfig() config {
	c := defaultCfg()
	b, err := os.ReadFile(cfgFile)
	if err == nil {
		_ = json.Unmarshal(b, &c)
	}
	if c.IntervalSec < 30 || c.IntervalSec > 3600 {
		c.IntervalSec = 180
	}
	if c.TimeoutSec < 3 || c.TimeoutSec > 60 {
		c.TimeoutSec = 10
	}
	if c.Target < 0 || c.Target > 2 {
		c.Target = 0
	}
	if c.CustomURL == "" {
		c.CustomURL = "https://example.com/"
	}
	return c
}
func writeCfg(c config) error {
	b, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(cfgFile, b, 0600)
}
func createChild(class, title string, style uint32, x, y, w, h, id int, ex uint32) uintptr {
	handle, _, _ := pCreateWindow.Call(uintptr(ex), uintptr(unsafe.Pointer(u16(class))), uintptr(unsafe.Pointer(u16(title))), uintptr(style|WS_CHILD|WS_VISIBLE), uintptr(x), uintptr(y), uintptr(w), uintptr(h), hwndMain, uintptr(id), 0, 0)
	ctrls[id] = handle
	if class == "STATIC" {
		msgSend(handle, WM_SETFONT, fontBody, 1)
	} else if class == "EDIT" || class == "BUTTON" || class == "COMBOBOX" {
		msgSend(handle, WM_SETFONT, fontBody, 1)
	}
	return handle
}
func label(id int, t string, x, y, w, h int, font uintptr) {
	handle := createChild("STATIC", t, SS_LEFT, x, y, w, h, id, 0)
	msgSend(handle, WM_SETFONT, font, 1)
}
func button(id int, t string, x, y, w, h int) {
	createChild("BUTTON", t, BS_PUSHBUTTON|WS_TABSTOP, x, y, w, h, id, 0)
}
func checkbox(id int, t string, x, y, w int) {
	createChild("BUTTON", t, BS_AUTOCHECKBOX|WS_TABSTOP, x, y, w, 28, id, 0)
}
func edit(id int, t string, x, y, w, h int, number bool) {
	var extra uint32 = ES_AUTOHSCROLL | WS_TABSTOP
	if number {
		extra |= ES_NUMBER
	}
	createChild("EDIT", t, extra, x, y, w, h, id, WS_EX_CLIENTEDGE)
}
func combo(id int, x, y, w, h int) {
	createChild("COMBOBOX", "", CBS_DROPDOWNLIST|CBS_HASSTRINGS|WS_TABSTOP, x, y, w, h, id, 0)
}
func createGUI() {
	label(200, "校园网保活助手", 27, 16, 430, 39, fontBig)
	label(201, "轻量请求保持认证活动 · 无需输入校园网账号密码", 29, 55, 650, 25, fontSmall)
	label(202, "连接状态", 42, 92, 180, 24, fontSmall)
	label(idStatus, "● 未启动", 42, 117, 250, 34, fontSemi)
	label(203, "上次检测", 373, 92, 210, 22, fontSmall)
	label(idLast, "暂无", 373, 117, 260, 30, fontBody)
	label(204, "下次检测", 663, 92, 200, 22, fontSmall)
	label(idNext, "—", 663, 117, 220, 30, fontBody)
	label(idCount, "成功 0  /  失败 0", 810, 124, 180, 27, fontSmall)
	label(205, "推荐预设", 40, 188, 220, 27, fontSemi)
	label(idPresetHint, "当前：均衡（推荐）", 737, 189, 230, 25, fontSmall)
	button(idPresetEco, "省流量  ·  每 5 分钟", 40, 224, 292, 43)
	button(idPresetNormal, "均衡推荐  ·  每 3 分钟", 351, 224, 292, 43)
	button(idPresetFast, "积极保活  ·  每 1 分钟", 662, 224, 292, 43)
	label(206, "参数设置", 40, 299, 160, 25, fontSemi)
	label(207, "请求间隔（秒） 30 - 3600", 43, 338, 245, 22, fontSmall)
	edit(idInterval, "180", 43, 365, 158, 29, true)
	label(208, "请求超时（秒） 3 - 60", 227, 338, 245, 22, fontSmall)
	edit(idTimeout, "10", 227, 365, 158, 29, true)
	label(209, "检测地址", 420, 338, 245, 22, fontSmall)
	combo(idTarget, 420, 365, 535, 180)
	for _, t := range []string{"微软联网检测（推荐）", "Firefox 联网检测", "自定义 URL（只校验状态码）"} {
		msgSend(ctrls[idTarget], CB_ADDSTRING, 0, uintptr(unsafe.Pointer(u16(t))))
	}
	label(210, "自定义检测 URL（选择自定义时启用）", 43, 403, 510, 23, fontSmall)
	edit(idURL, "https://example.com/", 43, 429, 912, 28, false)
	checkbox(idBypass, "绕过系统代理（校园网推荐）", 43, 469, 270)
	checkbox(idAwake, "运行时防止自动睡眠", 325, 469, 235)
	checkbox(idLogging, "记录本地日志", 592, 469, 160)
	label(211, "运行控制", 41, 503, 150, 25, fontSemi)
	button(idStart, "▶ 开始保活", 41, 533, 175, 42)
	button(idStop, "■ 停止", 226, 533, 125, 42)
	button(idTest, "立即检测", 361, 533, 140, 42)
	button(idSave, "保存参数", 511, 533, 140, 42)
	button(idOpenLog, "打开日志文件夹", 661, 533, 190, 42)
	checkbox(idStartup, "随 Windows 登录启动", 43, 580, 245)
	checkbox(idAutoRun, "打开本程序后自动保活", 315, 580, 260)
	label(212, "活动日志", 41, 618, 280, 26, fontSemi)
	label(213, "每次测试少量流量；认证是否延长由学校网关决定", 554, 624, 417, 22, fontSmall)
	l := createChild("EDIT", "", ES_MULTILINE|ES_READONLY|ES_AUTOVSCROLL|WS_VSCROLL, 42, 652, 915, 75, idLog, WS_EX_CLIENTEDGE)
	msgSend(l, WM_SETFONT, fontSmall, 1)
	label(idFooter, "提示：关机或休眠后程序无法运行；如需夜间保活，保持电脑唤醒。", 44, 744, 942, 23, fontSmall)
	enable(ctrls[idStop], false)
	loadToUI(saved)
}
func loadToUI(c config) {
	winText(ctrls[idInterval], strconv.Itoa(c.IntervalSec))
	winText(ctrls[idTimeout], strconv.Itoa(c.TimeoutSec))
	winText(ctrls[idURL], c.CustomURL)
	msgSend(ctrls[idTarget], CB_SETCURSEL, uintptr(c.Target), 0)
	enable(ctrls[idURL], c.Target == 2)
	setCheck(ctrls[idBypass], c.BypassProxy)
	setCheck(ctrls[idAwake], c.PreventSleep)
	setCheck(ctrls[idLogging], c.WriteLog)
	setCheck(ctrls[idStartup], c.StartWithWindows)
	setCheck(ctrls[idAutoRun], c.AutoRun)
	setPresetHint()
}
func setPresetHint() { winText(ctrls[idPresetHint], "当前："+currentPreset) }
func parseUI() (config, error) {
	c := saved
	a, e := strconv.Atoi(strings.TrimSpace(ctrlText(ctrls[idInterval])))
	if e != nil || a < 30 || a > 3600 {
		return c, fmt.Errorf("请求间隔必须是 30～3600 秒")
	}
	b, e := strconv.Atoi(strings.TrimSpace(ctrlText(ctrls[idTimeout])))
	if e != nil || b < 3 || b > 60 {
		return c, fmt.Errorf("请求超时必须是 3～60 秒")
	}
	c.IntervalSec = a
	c.TimeoutSec = b
	c.Target = int(msgSend(ctrls[idTarget], CB_GETCURSEL, 0, 0))
	c.CustomURL = strings.TrimSpace(ctrlText(ctrls[idURL]))
	if c.Target < 0 || c.Target > 2 {
		c.Target = 0
	}
	if c.Target == 2 {
		u, e := http.NewRequest("GET", c.CustomURL, nil)
		if e != nil || (u.URL.Scheme != "http" && u.URL.Scheme != "https") || u.URL.Host == "" {
			return c, fmt.Errorf("自定义地址需以 http:// 或 https:// 开头，且网址必须有效")
		}
	}
	c.BypassProxy = checked(ctrls[idBypass])
	c.PreventSleep = checked(ctrls[idAwake])
	c.WriteLog = checked(ctrls[idLogging])
	c.StartWithWindows = checked(ctrls[idStartup])
	c.AutoRun = checked(ctrls[idAutoRun])
	return c, nil
}
func messageBox(text, caption string, icon uintptr) {
	pMessageBox.Call(hwndMain, uintptr(unsafe.Pointer(u16(text))), uintptr(unsafe.Pointer(u16(caption))), icon|0x0)
}
func applyPreset(which int) {
	if isRunning {
		messageBox("请先停止保活，再修改预设。", "运行中", 0x30)
		return
	}
	interval := 180
	timeout := 10
	name := "均衡（推荐）"
	if which == idPresetEco {
		interval = 300
		timeout = 10
		name = "省流量"
	}
	if which == idPresetFast {
		interval = 60
		timeout = 8
		name = "积极保活"
	}
	winText(ctrls[idInterval], strconv.Itoa(interval))
	winText(ctrls[idTimeout], strconv.Itoa(timeout))
	currentPreset = name
	setPresetHint()
	appendLog("参数", "已选择预设："+name)
}
func appendLog(kind, line string) {
	timeStr := time.Now().Format("15:04:05")
	message := fmt.Sprintf("[%s] %-4s  %s\r\n", timeStr, kind, line)
	if ctrls[idLog] != 0 {
		h := ctrls[idLog]
		n := msgSend(h, WM_GETTEXTLENGTH, 0, 0)
		if n > 10000 {
			winText(h, "")
			n = 0
		}
		msgSend(h, EM_SETSEL, n, n)
		msgSend(h, EM_REPLACESEL, 0, uintptr(unsafe.Pointer(u16(message))))
	}
	if saved.WriteLog {
		f, e := os.OpenFile(logFile, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
		if e == nil {
			_, _ = f.WriteString(fmt.Sprintf("%s [%s] %s\n", time.Now().Format("2006-01-02 15:04:05"), kind, line))
			_ = f.Close()
		}
	}
}
func syncControls() {
	for _, i := range []int{idInterval, idTimeout, idTarget, idURL, idBypass, idAwake, idLogging, idPresetEco, idPresetNormal, idPresetFast} {
		enable(ctrls[i], !isRunning)
	}
	if !isRunning {
		target := int(msgSend(ctrls[idTarget], CB_GETCURSEL, 0, 0))
		enable(ctrls[idURL], target == 2)
	}
	enable(ctrls[idStart], !isRunning)
	enable(ctrls[idStop], isRunning)
	enable(ctrls[idTest], !isBusy)
	enable(ctrls[idSave], !isRunning)
}
func setStatus(t string) {
	if strings.Contains(t, "失败") || strings.Contains(t, "需要认证") {
		statusLevel = 2
	} else if strings.Contains(t, "保活") || strings.Contains(t, "检测中") {
		statusLevel = 1
	} else {
		statusLevel = 0
	}
	winText(ctrls[idStatus], t)
}
func updateCount() {
	winText(ctrls[idCount], fmt.Sprintf("成功 %d  /  失败 %d", successes, failures))
}
func setNextDisplay() {
	if isRunning && !nextDue.IsZero() {
		winText(ctrls[idNext], nextDue.Format("15:04:05"))
	} else if isBusy && isRunning {
		winText(ctrls[idNext], "检测中...")
	} else {
		winText(ctrls[idNext], "—")
	}
}
func prepareClient() (string, string) {
	switch saved.Target {
	case 1:
		return "http://detectportal.firefox.com/success.txt", "success"
	case 2:
		return saved.CustomURL, ""
	default:
		return "http://www.msftconnecttest.com/connecttest.txt", "Microsoft Connect Test"
	}
}
func runProbe(seq int, c config) {
	url, expected := prepareFor(c)
	at := time.Now()
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(c.TimeoutSec)*time.Second)
	defer cancel()
	request, e := http.NewRequestWithContext(ctx, "GET", url, nil)
	if e != nil {
		resultCh <- probeResult{seq: seq, at: at, err: e.Error()}
		return
	}
	request.Header.Set("User-Agent", "CampusKeepAliveGUI/1.0")
	request.Header.Set("Cache-Control", "no-cache")
	tr := http.DefaultTransport.(*http.Transport).Clone()
	if c.BypassProxy {
		tr.Proxy = nil
	}
	tr.DisableKeepAlives = true
	defer tr.CloseIdleConnections()
	cli := &http.Client{Transport: tr, Timeout: time.Duration(c.TimeoutSec) * time.Second, CheckRedirect: func(req *http.Request, via []*http.Request) error { return http.ErrUseLastResponse }}
	resp, e := cli.Do(request)
	if e != nil {
		resultCh <- probeResult{seq: seq, at: at, err: e.Error()}
		return
	}
	defer resp.Body.Close()
	data, e := io.ReadAll(io.LimitReader(resp.Body, 64*1024))
	if e != nil {
		resultCh <- probeResult{seq: seq, at: at, err: e.Error()}
		return
	}
	ok := false
	reason := ""
	if resp.StatusCode >= 300 && resp.StatusCode < 400 {
		reason = fmt.Sprintf("HTTP %d 重定向，可能需要重新认证", resp.StatusCode)
	} else if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		reason = fmt.Sprintf("HTTP %d", resp.StatusCode)
	} else if expected != "" {
		if strings.TrimSpace(string(data)) == expected {
			ok = true
			reason = "校验内容符合预期"
		} else {
			reason = "返回内容不匹配，可能进入认证页面"
		}
	} else {
		ok = true
		reason = fmt.Sprintf("HTTP %d（仅校验状态，不能确认未跳转到认证页）", resp.StatusCode)
	}
	resultCh <- probeResult{seq: seq, at: at, success: ok, detail: reason}
}
func prepareFor(c config) (string, string) {
	switch c.Target {
	case 1:
		return "http://detectportal.firefox.com/success.txt", "success"
	case 2:
		return c.CustomURL, ""
	default:
		return "http://www.msftconnecttest.com/connecttest.txt", "Microsoft Connect Test"
	}
}
func beginTest(manual bool) {
	if isBusy {
		return
	}
	c := saved
	if !isRunning {
		var err error
		c, err = parseUI()
		if err != nil {
			messageBox(err.Error(), "参数错误", 0x30)
			return
		}
	}
	isBusy = true
	onDemand = manual
	taskSeq++
	seq := taskSeq
	appendLog("请求", fmt.Sprintf("开始检测：%s", func() string { u, _ := prepareFor(c); return u }()))
	if isRunning {
		setStatus("● 检测中...")
		winText(ctrls[idNext], "检测中...")
	}
	syncControls()
	go runProbe(seq, c)
}
func handleStart() {
	if isRunning {
		return
	}
	c, e := parseUI()
	if e != nil {
		messageBox(e.Error(), "参数错误", 0x30)
		return
	}
	saved = c
	isRunning = true
	nextDue = time.Time{}
	successes, failures = 0, 0
	updateCount()
	setStatus("● 正在保活")
	appendLog("启动", fmt.Sprintf("间隔 %d 秒，超时 %d 秒，%s", saved.IntervalSec, saved.TimeoutSec, func() string {
		if saved.BypassProxy {
			return "不使用系统代理"
		}
		return "使用系统代理"
	}()))
	setNextDisplay()
	syncControls()
	if saved.PreventSleep {
		pSetThreadExec.Call(0x80000001)
		lastAwake = time.Now()
		appendLog("系统", "已启用防止系统自动睡眠（不会阻止用户主动睡眠）")
	}
	if !isBusy {
		beginTest(false)
	} else {
		nextDue = time.Now().Add(time.Duration(c.IntervalSec) * time.Second)
	}
}
func handleStop() {
	if !isRunning {
		return
	}
	isRunning = false
	pSetThreadExec.Call(0x80000000)
	nextDue = time.Time{}
	setStatus("● 已停止")
	setNextDisplay()
	appendLog("停止", "已停止定时请求；正在进行的请求可能仍会返回结果")
	syncControls()
}
func handleSave() {
	if isRunning {
		messageBox("请先停止保活再保存参数。", "提示", 0x30)
		return
	}
	c, e := parseUI()
	if e != nil {
		messageBox(e.Error(), "参数错误", 0x30)
		return
	}
	if err := writeCfg(c); err != nil {
		messageBox("保存参数失败："+err.Error(), "错误", 0x10)
		return
	}
	if err := setAutoStartup(c.StartWithWindows); err != nil {
		messageBox("参数已保存，但设置开机自启失败："+err.Error(), "部分成功", 0x30)
	}
	saved = c
	appendLog("设置", "已保存到 "+cfgFile)
	messageBox("设置已保存。下次打开程序会自动读取。\n\n如果已启用「随 Windows 登录启动」，请勿移动 EXE 文件。", "保存成功", 0x40)
}
func receiveResult(r probeResult) {
	if r.seq != taskSeq {
		return
	}
	isBusy = false
	if r.err != "" {
		failures++
		appendLog("失败", r.err)
		winText(ctrls[idLast], "失败 · "+time.Now().Format("15:04:05"))
		if isRunning {
			setStatus("● 检测失败")
		}
	}
	if r.err == "" && r.success {
		successes++
		appendLog("正常", r.detail)
		winText(ctrls[idLast], "成功 · "+time.Now().Format("15:04:05"))
		if isRunning {
			setStatus("● 正在保活")
		}
	}
	if r.err == "" && !r.success {
		failures++
		appendLog("异常", r.detail)
		winText(ctrls[idLast], "异常 · "+time.Now().Format("15:04:05"))
		if isRunning {
			setStatus("● 可能需要认证")
		}
	}
	updateCount()
	if isRunning {
		nextDue = time.Now().Add(time.Duration(saved.IntervalSec) * time.Second)
	}
	setNextDisplay()
	syncControls()
}
func onTimer() {
	for {
		select {
		case r := <-resultCh:
			receiveResult(r)
		default:
			goto FINISH
		}
	}
FINISH:
	if isRunning && !isBusy && !nextDue.IsZero() && !time.Now().Before(nextDue) {
		beginTest(false)
	}
	if isRunning && saved.PreventSleep && time.Since(lastAwake) >= 30*time.Second {
		pSetThreadExec.Call(0x80000001)
		lastAwake = time.Now()
	}
}
func regAction(enable bool) error {
	keyname := syscall.StringToUTF16Ptr(`Software\Microsoft\Windows\CurrentVersion\Run`)
	var key uintptr
	r, _, _ := pRegCreateKey.Call(0x80000001, uintptr(unsafe.Pointer(keyname)), 0, 0, 0, 0x0002, 0, uintptr(unsafe.Pointer(&key)), 0)
	if r != 0 {
		return fmt.Errorf("无法打开用户启动项，错误码 %d", r)
	}
	defer pRegCloseKey.Call(key)
	val := syscall.StringToUTF16Ptr("CampusKeepAliveGUI")
	if !enable {
		r, _, _ := pRegDelValue.Call(key, uintptr(unsafe.Pointer(val)))
		if r == 0 || r == 2 {
			return nil
		}
		return fmt.Errorf("移除启动项失败：%d", r)
	}
	self, e := os.Executable()
	if e != nil {
		return e
	}
	data := syscall.StringToUTF16(`"` + self + `"`)
	r, _, _ = pRegSetValue.Call(key, uintptr(unsafe.Pointer(val)), 0, 1, uintptr(unsafe.Pointer(&data[0])), uintptr(len(data)*2))
	if r != 0 {
		return fmt.Errorf("写入启动项失败：%d", r)
	}
	return nil
}
func setAutoStartup(v bool) error { return regAction(v) }
func openLogFolder() {
	e := exec.Command("explorer.exe", dataDir()).Start()
	if e != nil {
		messageBox("无法打开日志目录："+e.Error(), "错误", 0x10)
	}
}
func drawCard(hdc uintptr, x, y, w, h int32) {
	// White surfaces with subdued borders and 12px corners.
	br, _, _ := pCreateSolidBrush.Call(cref(255, 255, 255))
	pen, _, _ := pCreatePen.Call(0, 1, cref(219, 226, 237))
	oldBr, _, _ := pSelectObject.Call(hdc, br)
	oldPen, _, _ := pSelectObject.Call(hdc, pen)
	pRoundRect.Call(hdc, uintptr(x), uintptr(y), uintptr(x+w), uintptr(y+h), 14, 14)
	pSelectObject.Call(hdc, oldBr)
	pSelectObject.Call(hdc, oldPen)
	pDeleteObject.Call(br)
	pDeleteObject.Call(pen)
}
func repaint(hwnd uintptr) {
	var ps paintStruct
	hdc, _, _ := pBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	if hdc == 0 {
		return
	}
	var r rect
	pGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&r)))
	pFillRect.Call(hdc, uintptr(unsafe.Pointer(&r)), brushBG)
	width := r.Right
	drawCard(hdc, 22, 82, width-44, 83)
	drawCard(hdc, 22, 177, width-44, 112)
	drawCard(hdc, 22, 299, width-44, 195)
	logH := r.Bottom - 608
	if logH < 92 {
		logH = 92
	}
	drawCard(hdc, 22, 607, width-44, logH)
	pEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
}
func resize(hwnd uintptr) {
	var r rect
	pGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&r)))
	width := int(r.Right - r.Left)
	height := int(r.Bottom - r.Top)
	clientHeight = height
	if width < 850 {
		width = 850
	}
	move := func(id, x, y, w, h int) {
		if ctrls[id] != 0 {
			pMoveWindow.Call(ctrls[id], uintptr(x), uintptr(y), uintptr(w), uintptr(h), 1)
		}
	}
	move(203, 373, 92, 210, 22)
	move(idLast, 373, 117, 260, 30)
	move(204, width-355, 92, 180, 22)
	move(idNext, width-355, 117, 200, 30)
	move(idCount, width-198, 124, 180, 27)
	// Extend the target selector and custom URL to the right edge.
	move(idTarget, 420, 365, width-465, 185)
	move(idURL, 43, 429, width-86, 28)
	move(idPresetHint, width-273, 189, 250, 25)
	move(idPresetEco, 40, 224, (width-120)/3, 43)
	move(idPresetNormal, 50+(width-120)/3, 224, (width-120)/3, 43)
	move(idPresetFast, 60+2*((width-120)/3), 224, (width-120)/3, 43)
	move(213, width-470, 624, 444, 22)
	logHeight := height - 685
	if logHeight < 30 {
		logHeight = 30
	}
	move(idLog, 42, 652, width-84, logHeight)
	move(idFooter, 42, height-21, width-84, 21)
	pInvalidateRect.Call(hwnd, 0, 1)
}
func createFonts() {
	makeFont := func(height, weight int) uintptr {
		v, _, _ := pCreateFont.Call(uintptr(int32(-height)), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 0, 0, uintptr(unsafe.Pointer(u16("Microsoft YaHei UI"))))
		return v
	}
	fontBody = makeFont(16, 400)
	fontSmall = makeFont(14, 400)
	fontSemi = makeFont(20, 600)
	fontBig = makeFont(29, 700)
}
func wndProc(hwnd uintptr, umsg uint32, wParam, lParam uintptr) uintptr {
	switch umsg {
	case WM_CREATE:
		hwndMain = hwnd
		createGUI()
		pSetTimer.Call(hwnd, 1, 250, 0)
		appendLog("欢迎", "选择推荐预设或修改参数，点击「开始保活」")
		if saved.AutoRun {
			handleStart()
		}
		return 0
	case WM_COMMAND:
		id := lo(wParam)
		notify := hi(wParam)
		if notify == BN_CLICKED {
			switch id {
			case idPresetEco, idPresetNormal, idPresetFast:
				applyPreset(id)
			case idStart:
				handleStart()
			case idStop:
				handleStop()
			case idTest:
				beginTest(true)
			case idSave:
				handleSave()
			case idOpenLog:
				openLogFolder()
			}
		}
		if id == idTarget && notify == CBN_SELCHANGE && !isRunning {
			enable(ctrls[idURL], int(msgSend(ctrls[idTarget], CB_GETCURSEL, 0, 0)) == 2)
		}
		if (id == idInterval || id == idTimeout) && notify == EN_CHANGE && !isRunning {
			t := strings.TrimSpace(ctrlText(ctrls[idInterval]))
			if t != "180" && t != "300" && t != "60" {
				currentPreset = "自定义"
				setPresetHint()
			}
		}
		return 0
	case WM_TIMER:
		onTimer()
		return 0
	case WM_SIZE:
		if len(ctrls) > 0 {
			resize(hwnd)
		}
		return 0
	case WM_PAINT:
		repaint(hwnd)
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_CTLCOLORSTATIC:
		id, _, _ := pGetDlgCtrlID.Call(lParam)
		color := cref(30, 45, 68)
		if id == idStatus {
			if statusLevel == 1 {
				color = cref(16, 135, 88)
			} else if statusLevel == 2 {
				color = cref(193, 64, 64)
			}
		}
		pSetTextColor.Call(wParam, color)
		pSetBkMode.Call(wParam, TRANSPARENT)
		switch id {
		case 200, 201, 211, idFooter:
			return brushBG
		}
		return brushWhite
	case WM_CLOSE:
		handleStop()
		pKillTimer.Call(hwnd, 1)
		pDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		pPostQuitMessage.Call(0)
		return 0
	case 0x0024: // WM_GETMINMAXINFO
		info := (*minMaxInfo)(unsafe.Pointer(lParam))
		info.MinTrackSize = point{X: 1000, Y: 760}
		return 0
	}
	v, _, _ := pDefWindowProc.Call(hwnd, uintptr(umsg), wParam, lParam)
	return v
}
func main() {
	runtime.LockOSThread()
	mutex, _, mutexErr := pCreateMutex.Call(0, 0, uintptr(unsafe.Pointer(u16("Local\\CampusKeepAliveGUI_OneInstance"))))
	if mutexErr == syscall.ERROR_ALREADY_EXISTS {
		pMessageBox.Call(0, uintptr(unsafe.Pointer(u16("程序已经在运行，请切换到已经打开的窗口。"))), uintptr(unsafe.Pointer(u16("校园网保活助手"))), 0x40)
		if mutex != 0 {
			pCloseHandle.Call(mutex)
		}
		return
	}
	if mutex != 0 {
		defer pCloseHandle.Call(mutex)
	}
	_ = os.MkdirAll(dataDir(), 0700)
	cfgFile = filepath.Join(dataDir(), "settings.json")
	logFile = filepath.Join(dataDir(), "keepalive.log")
	saved = loadConfig()
	createFonts()
	brushBG, _, _ = pCreateSolidBrush.Call(cref(245, 247, 251))
	brushWhite, _, _ = pCreateSolidBrush.Call(cref(255, 255, 255))
	instance, _, _ := pGetModuleHandle.Call(0)
	var wc wndClass
	wc.Size = uint32(unsafe.Sizeof(wc))
	wc.WndProc = syscall.NewCallback(wndProc)
	wc.Instance = instance
	wc.Icon, _, _ = pLoadIcon.Call(0, IDI_APPLICATION)
	wc.IconSm = wc.Icon
	wc.Cursor, _, _ = pLoadCursor.Call(0, IDC_ARROW)
	wc.Background = brushBG
	wc.ClassName = u16("CampusKeepAliveGUIWindowClass")
	r, _, _ := pRegisterClassEx.Call(uintptr(unsafe.Pointer(&wc)))
	if r == 0 {
		return
	}
	// 1030x820; the window is freely resizable vertically for additional log history.
	hwnd, _, _ := pCreateWindow.Call(0, uintptr(unsafe.Pointer(wc.ClassName)), uintptr(unsafe.Pointer(u16("校园网保活助手  |  Campus Keep Alive"))), WS_OVERLAPPEDWINDOW|WS_VISIBLE|WS_CLIPCHILDREN, 130, 70, 1040, 820, 0, 0, instance, 0)
	if hwnd == 0 {
		return
	}
	pShowWindow.Call(hwnd, SW_SHOW)
	pUpdateWindow.Call(hwnd)
	var m msg
	for {
		r, _, _ := pGetMessage.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessage.Call(uintptr(unsafe.Pointer(&m)))
	}
	pSetThreadExec.Call(0x80000000)
}
